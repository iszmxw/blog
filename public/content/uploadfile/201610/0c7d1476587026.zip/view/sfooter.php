<div id="footer">
<div class="copyright">Copyright © 2014  &nbsp;<?php echo Option::get('blogname'); ?>

<!-- 以下为本模板的版权信息，尊重作者劳动成果，请自觉保留内容，谢谢支持 -->

<hr/>基于 <a href="http://www.emlog.net/" target="_blank">Emlog</a> 开发 , 主题作者: <a href="http://xiaows.com/" target="_blank">笑忘书</a>

</div>
</div><!-- footer 结束 -->
</div><!-- 页面主体 结束 -->
</body></html>