<?php if(!defined('EMLOG_ROOT')) {exit('error!');}?>
<div id="content" class="write">
<form action="./index.php?action=savelog" method="post">
<div class="tips">文章标题</div>
<input type="text" name="title" value="<?php echo $title; ?>" />
<div class="tips">所选分类</div>
<select name="sort" id="sort">
<?php
			$sorts[] = array('sid'=>-1, 'sortname'=>'请选择文章分类--');
			foreach($sorts as $val):
			$flg = $val['sid'] == $sortid ? 'selected' : '';
			?>
			<option value="<?php echo $val['sid']; ?>" <?php echo $flg; ?>><?php echo $val['sortname']; ?></option>
			<?php endforeach; ?>
	      </select>
<div class="tips">文章内容(支持html)</div>
<script type="text/javascript">
function addText(text){
 var srk = document.getElementById("new-content");
 srk.value += text;
}
</script>
<div class="addword">
<a onclick='addText("&lt;p&gt;");return false;'>段始</a>

<a onclick='addText("&lt;/p&gt;");return false;'>段终</a>

<a onclick='addText("&lt;br/&gt;");return false;'>换行</a>

<a onclick='addText("&lt;b&gt;&lt;/b&gt;");return false;'>加粗</a>

<a onclick='addText("&lt;a href=\"\"&nbsp;target=\"_blank\"&nbsp;title=\"\"&gt;&lt;/a&gt;");return false;'>链接</a>

<a onclick='addText("&lt;img&nbsp;src=\"\"&nbsp;alt=\"\"/&gt;");return false;'>插图</a>

<a onclick='addText("&lt;img&nbsp;src=\"\"&nbsp;alt=\"\"&nbsp;class=\"screenshot\"/&gt;");return false;'>截图</a>

<a onclick='addText("&lt;span&nbsp;class=\"nickname\"&gt;&lt;/span&gt;");return false;'>昵称</a>

<a onclick='addText("&lt;h3&gt;&lt;/h3&gt;");return false;'>标题</a>

<a onclick='addText("&lt;strong&gt;&lt;/strong&gt;");return false;'>强调</a>

<a onclick='addText("&lt;div&nbsp;class=\"quote\"&gt;&lt;/div&gt;");return false;'>引用</a>

<a onclick='addText("&lt;pre&nbsp;class=\"sh_php\"&gt;&lt;/pre&gt;");return false;'>PHP</a>

<a onclick='addText("&lt;pre&nbsp;class=\"sh_css\"&gt;&lt;/pre&gt;");return false;'>CSS</a>

<a onclick='addText("&lt;pre&nbsp;class=\"sh_html\"&gt;&lt;/pre&gt;");return false;'>HTML</a>

<a onclick='addText("&lt;pre&nbsp;class=\"sh_javascript\"&gt;&lt;/pre&gt;");return false;'>JS</a>
</div>

<textarea name="content" class="post-textarea" id="new-content"><?php echo $content; ?></textarea><br />
<div class="tips">内容摘要(可吸引读者)</div> 
<textarea name="excerpt" class="excerpt"><?php echo $excerpt; ?></textarea>
<div class="tips">给文章贴标签</div> 
<input type="text" name="tag" value="<?php echo $tagStr; ?>" />
<input type="hidden" name="gid" value=<?php echo $logid; ?> />
<input name="token" id="token" value="<?php echo LoginAuth::genToken(); ?>" type="hidden" />
<input type="hidden" name="author" value=<?php echo $author; ?> />
<input name="date" type="hidden" value="<?php print !empty($date) ? gmdate('Y-m-d H:i:s', $date) : ''; ?>" />
<input type="submit" value="发布文章" />
</form>
</div>
