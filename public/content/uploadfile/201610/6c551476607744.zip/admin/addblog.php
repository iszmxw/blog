<?php
 session_start(); if(isset($_SESSION['admin'])==false){header('location:login.php');exit;}

$title='写文章';
require 'head.tpl';

        if(isset($_POST['submit'])){ 
//增加博客文章操作
   
        $q=array(
'title'=>$dbConn->escape(htmlspecialchars($_POST['title'])),
'sortid'=>(int)$_POST['fl'],
'uid'=>'1',
'text'=>$dbConn->escape(htmlspecialchars($_POST['text'])),
'cs'=>'0',
'time'=>time()); 

        $if=$dbConn->insert_array(DB_QZ.'_article',$q);

     if($if){$echo='发表成功';
}else{$echo='发表失败';}
ailierror($echo);
     }

   $for=$dbConn->select("SELECT * FROM ".DB_QZ."_sort WHERE `lock`='article' ORDER BY id DESC");
$template->display('/addblog.html');
require 'foot.tpl';
?>