<?php
 session_start(); if(isset($_SESSION['admin'])==false){header('location:login.php');exit;}

$title='增加分类';
require 'head.tpl';
 if(isset($_POST['submt'])){

if(preg_match('/^[a-zA-Z0-9\x{4e00}-\x{9fa5}]{2,4}$/u',$dbConn->escape(htmlspecialchars($_POST["sortname"])))){ 
        $q=array(
'name'=>$dbConn->escape(htmlspecialchars($_POST['sortname'])),
'lock'=>$_POST['sort']); 

        $if=$dbConn->insert_array(DB_QZ.'_sort',$q);

          if($if){$echo='增加成功';}else{$echo='增加失败';}
ailierror($echo);
   }else{echo '非法填写';}
  }

echo '<form action="addsort.php" method="post">
分类名称:<input type="text" size="10" name="sortname" /><br/>增加到:<select name="sort">
<option value="article">文章</option>
<option value="link">友链</option>
</select><br/>
<input type="submit" value="增加" name="submt"/>
';
require 'foot.tpl';
?>