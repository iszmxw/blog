<?php
 session_start(); if(isset($_SESSION['admin'])==false){header('location:login.php');exit;} 

$title='修改信息';
require './head.tpl';

   if(isset($_POST['pb'])==TRUE){

      $q="UPDATE ".DB_QZ."_admin SET 
head='".$dbConn->escape(htmlspecialchars($_POST["gr"]))."',name='".$dbConn->escape(htmlspecialchars($_POST["user"]))."',pass='".$dbConn->escape(htmlspecialchars($_POST["pass"]))."',way='".$dbConn->escape(htmlspecialchars($_POST["way"]))."',bmail='".$dbConn->escape(htmlspecialchars($_POST["bmail"]))."',email='".$dbConn->escape(htmlspecialchars($_POST["email"]))."', epass='".$dbConn->escape(htmlspecialchars($_POST["epass"]))."'  WHERE id='1' LIMIT 1";

     $insert=$dbConn->query($q);

      if($insert){
     $echo='修改成功';}else{$echo='修改失败！';}

ailierror($echo);
         }
   $q="SELECT * FROM ".DB_QZ."_admin WHERE id=1";
   $db=$dbConn->get_row($q);
    $template->display('/ailimm.html');

require './foot.tpl';
?>