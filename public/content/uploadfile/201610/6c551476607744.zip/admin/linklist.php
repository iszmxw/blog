<?php
 session_start(); if(isset($_SESSION['admin'])==false){header('location:login.php');exit;}

$title='友链列表';
require 'head.tpl';

  if(isset($_GET["page"])){
     $page=(int)$_GET["page"];
    }else{
     $page=1;
   }

    $size=($page-1)*10;
    $q= "SELECT * FROM ".DB_QZ."_link ";
    if(isset($_POST["sort"])){$q.="WHERE name LIKE '%".$_POST["sort"]."%' ";}

    if(isset($_GET["list"])==TRUE){
       if($_GET["list"]==1){
         $list="id";
        }else if($_GET["list"]==2){
         $list="iko";
        }else if($_GET["list"]==3){
         $list="ko";
       }else if($_GET["list"]==4){
         $list="id";$q.="WHERE `sh`='0' ";
      }
     }else{
         $list="id";
    }

    if(isset($_GET["sc"])==TRUE){
       if($_GET["sc"]==1){
         $sc="DESC";
        }else if($_GET["sc"]==2){
         $sc="ASC";
       }
    }else{
      $sc="DESC";
   }
          
    $m=$q."ORDER BY ".$list." ".$sc." LIMIT ".$size.",10";
    $for=$dbConn->select($m); 
    $count=$dbConn->count($q);
    $num=ceil($count/10);
     $pageNext=$page+1;
     $pageFront=$page-1;
    if($page<$num and $page<2){
      $pre=true;
$next=false;$front=false;
     }elseif($page>1 and $page<$num){
      $next=true;
$pre=false;$front=false;
     }elseif($page==$num and $page>1){
         $next=false;
$pre=false;$front=true;
     }else{
        $next=false;
$pre=false;$front=false;
    }
 
    $template->display('/linklist.html'); 
require 'foot.tpl';
?>