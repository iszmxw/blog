<?php
session_start();
$title='登录';
require 'head.tpl';
if(!isset($_SESSION['admin'])){}else{ 
    $login=isset($_GET["Login"])
?$_GET["Login"]:NULL;
   if($_GET['Login']=='outLogin'){
unset($_SESSION['admin']);

if(isset($_SESSION['adminstatus'])==TRUE){
 unset($_SESSION['adminstatus']);
}
echo '成功退出后台系统，是否需要重新<a href="./login.php">登录</a>';
exit();
  }}

if(isset($_POST['submit'])){

   $query="SELECT * FROM ".DB_QZ."_admin WHERE name='".$dbConn->escape(htmlspecialchars($_POST["user"]))."'and pass='".$dbConn->escape(htmlspecialchars($_POST["pass"]))."' and id='1' limit 1";

   if($dbConn->count($query)==1){
      $fetch=$dbConn->get_row($query);
      $_SESSION['admin']=$fetch['id'];
      echo '登录成功！<br/>用户名：'.$_POST['user'].'已成功进入后台！<br/><a href="./">»点击进入操作面板</a><br/>';
    }else{
     die('<font color="red">你输入的信息无法登录,请检查后认真填写！</font>');
    }
}else{
$template->display('/login.html');
   }

require './foot.tpl';
?>
