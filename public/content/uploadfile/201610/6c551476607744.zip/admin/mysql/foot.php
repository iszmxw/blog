<?php
echo "<br/>【<a href='../'>返回后台管理</a>】<br/>©糖果技术<br/>";
?>