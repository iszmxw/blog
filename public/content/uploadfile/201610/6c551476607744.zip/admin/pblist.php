<?php
 session_start(); if(isset($_SESSION['admin'])==false){header('location:login.php');exit;}

$title='排版列表';
require 'head.tpl';
   if(isset($_GET["page"])){
     $page=(int)$_GET["page"];
   }else{
     $page=1;
   }

   if(!isset($_GET["page"]) or $_GET["page"]==1){$size=1;}else{
    $size=($page-1)*10;}
    $q= "SELECT * FROM ".DB_QZ."_pb ";
    if(isset($_POST["sort"])){$q.="WHERE top LIKE '%".$_POST["sort"]."%' ";}
    $m=$q."ORDER BY id ASC LIMIT ".$size.",10";
   $for=$dbConn->select($m); 
    $count=$dbConn->count($q);
    $num=ceil($count/10);
     $pageNext=$page+1;
     $pageFront=$page-1;
    if($page<$num and $page<2){
      $pre=true;
$next=false;$front=false;
     }elseif($page>1 and $page<$num){
      $next=true;
$pre=false;$front=false;
     }elseif($page==$num and $page>1){
         $next=false;
$pre=false;$front=true;
     }else{
        $next=false;
$pre=false;$front=false;
    }
 
    $template->display('/pblist.html'); 
require 'foot.tpl';
?>