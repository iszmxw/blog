﻿<?php
 session_start(); if(isset($_SESSION['admin'])==false){header('location:login.php');exit;}
$title='备份数据|恢复数据';
require 'head.tpl';

if(isset($_GET['back'])==false){exit;}
 if($_GET['back']=='back'){
  if(isset($_POST['delete'])){

   $_SESSION['sjtime']=date('YmdHi',time());
   $q="SHOW TABLES ";
   $array=$dbConn->select($q);
   $count=$dbConn->count($q);

   for($i=0;$i<$count;$i++){
    $s="SHOW CREATE TABLE ".$array[$i][0];
    $e=$dbConn->select($s);
    $fopen=fopen('back/back'.$_SESSION['sjtime'].'.zip','a+');
     fwrite($fopen,$dbConn->escape($e[0][1]).';<br/>;
');
fclose($fopen);
}
   for($i=0;$i<$count;$i++){
    $j="SELECT * FROM ".$array[$i][0];
    if($dbConn->count($j)>0){
     $g=$dbConn->select($j);
     $str=str_replace('SELECT * FROM ','',$j);

      for($l=0;$l<count($g);$l++){
       $insert='INSERT INTO `'.$str.'`
 VALUES(';
       $m='';
       for($r=0;$r<count($g[0])/2;$r++){
         $m.='"'.$g[$l][$r].'",';
        }
       $insert=$insert.$m.');<br/>';
       $insert=str_replace(',);',');',$insert);
       $fopen=fopen('back/back'.$_SESSION['sjtime'].'.zip','a+');
       fwrite($fopen,$insert.';
');
       fclose($fopen);
      }
    }
  }
    $x=$dbConn->get_row("SELECT bmail,email,epass,way FROM ".DB_QZ."_admin WHERE id='1'");

  echo '<a href="back/back'.$_SESSION['sjtime'].'.zip">下载该备份文件</a>';

//引用phpmailer
require("../inc/class.phpmailer.php");

$mail             = new PHPMailer();

$mail->IsSMTP();
$mail->Host="smtp.".$x["way"].".com";
$mail->SMTPAuth   = true;
  if($seed['way']=='gmail'){
    $mail->SMTPSecure = "ssl";
    $mail->Port       = 465;
   }else{
    $mail->Port       =25;
   }
$mail->Username   = $x["email"];
$mail->Password   = $x["epass"];
$mail->From       = $x["email"]."@".$x["way"].".com";
$mail->CharSet="utf-8";
$mail->FromName   = "网站备份文件";
$mail->Subject    = "附件";
$mail->AltBody    = "数据文件，请谨慎保存！"; 
$mail->WordWrap   = 50;
$mail->MsgHTML("数据文件");
$mail->AddReplyTo($x["email"]."@".$x["way"].".com","备份");
$mail->AddAttachment("back/back".$_SESSION["sjtime"].".zip");
$mail->AddAddress($x["bmail"],"收信人");
$mail->IsHTML(true);
    if(!$mail->Send()) {
  echo "<br/>-<a href='sj.php?back=xl&url=".$_SESSION["sjtime"]."'>删除备份文件</a><br/><br/>附件发送失败，原因是:" . $mail->ErrorInfo;
   } else {
  echo "<br/>邮箱发送成功";
@unlink('./back/back'.$_SESSION['sjtime'].'.zip');
  }

echo '<br/><em>*</em>如果邮件发送成功,文件将被删除,你无法下载备份数据,请查收邮箱';
 
   }else{
        echo <<<html
是否要备份所有数据？<br/>
<form action="sj.php?back=back" method="post">
<input type="submit" name="delete" value="备份所有数据"/><br/><a href="./"
>返回管理首页</a></form>
html;
    }

}elseif($_GET['back']=='return'){
   if(isset($_POST['go'])){
     $file=file_get_contents($_FILES["file"]["tmp_name"]);
    $file=str_replace('\n','',$file);
      $explode=explode(';<br/>;',$file);

    $a=0;$b=0;$error="";

     for($i=0;$i<count($explode)-1;$i++){

       $query=$dbConn->query($explode[$i]);

        if($query){$a++;}else{$b++;

         $error.=$explode[$i].'<br/>';}

         }
           echo '成功执行'.$a.'条SQL，失败'.$b.'条，总计'.$i.'条<br/>失败SQL语句：'.$error.'<hr/>';
 }else{
  echo '<form enctype="multipart/form-data" method="post" action="sj.php?back=return">
.sql文件:<input type="file" name="file"/><br/>
<input type="submit" value="导入" name="go" />
<br/>-
<a href="sj.php?back=all">先清除所有数据</a>
</form>
<em>*</em>注意:导入的文件必须为本程序导出的数据文件,否则可能会损坏数据库';

   }
 }elseif($_GET['back']=='xl'){
    $link=@unlink('./back/back'.$_GET['url'].'.zip');
 }elseif($_GET['back']=='all'){
  if(isset($_POST['delete'])){
   $q="SHOW TABLES ";
   $explode=$dbConn->select($q);
   $count=$dbConn->count($q);

    $a=0;$b=0;$error="";

     for($i=0;$i<$count;$i++){

       $query=$dbConn->query("DROP TABLE ".$explode[$i][0]);

        if($query){$a++;}else{$b++;

         $error.=$explode[$i][0].'<br/>';}

         }
           echo '成功删除'.$a.'个数据表，失败'.$b.'个，总计'.$i.'个<br/>没有删除的表有：'.$error.'<hr/>';
}else{

 echo <<<html
是否要清除所有数据？<br/>
<form action="sj.php?back=all" method="post">
<input type="submit" name="delete" value="确定要清除全部数据"/><br/><a href="./"
>返回管理首页</a></form>
html;
  }
}
require 'foot.tpl';
?>