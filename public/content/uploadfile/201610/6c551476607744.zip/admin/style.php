<?php
 session_start(); if(isset($_SESSION['admin'])==false){header('location:login.php');exit;}
 
$title='CSS样式';
require 'head.tpl';

        if(isset($_POST['pb'])==TRUE){

        $q="UPDATE ".DB_QZ."_style SET name='".$dbConn->escape(htmlspecialchars($_POST["pb_t"]))."',text='".$dbConn->escape(htmlspecialchars($_POST["pb_nr"]))."' WHERE id=".(int)$_POST["id"];

     $insert=$dbConn->query($q);

if($insert){echo '修改成功！';}else{die('修改失败！');}

         }elseif(isset($_POST['add'])){


            if(!empty($_POST['pb_t']) and !empty($_POST['pb_nr'])){}else{die('增加内容为空,错误!');}

            if(preg_match('/.{2,15}/',$dbConn->escape(htmlspecialchars($_POST["pb_t"])))){ 
        $q=array(
'name'=>$dbConn->escape(htmlspecialchars($_POST['pb_t'])),
'text'=>$dbConn->escape(htmlspecialchars($_POST['pb_nr']))
); 

        $if=$dbConn->insert_array(DB_QZ.'_style',$q);

          if($if){echo '增加成功';}else{echo '增加失败';} 

   } 


         }elseif(isset($_GET['xg'])){


      if(isset($_GET['id'])){
          $id=(int)$_GET['id'];
          if($id<1){die('错误');
           }else{
           $q="SELECT name,text FROM ".DB_QZ."_style WHERE id='".$id."' LIMIT 1";
 
              $q=$dbConn->get_row($q);}
 
echo '<form action="style.php" method="post">
<input type="hidden" name="id" value="'.$_GET['id'].'"/>
 名称:<br/> <input type="text" name="pb_t" value="'.$q['name'].'"/><br/>
 CSS内容:<br/> <textarea name="pb_nr" cols="35" rows="15">'.$q['text'].'</textarea><br/>
<input name="pb" type="submit" value="修改样式">
</form>';
 
  
}else{

    if(isset($_GET['p'])){$p=(int)$_GET['p'];}else{$p=1;}

$page=($p-1)*10;

        $q=$dbConn->count("SELECT * FROM ".DB_QZ."_style");

       $m= "SELECT * FROM ".DB_QZ."_style ORDER BY id DESC LIMIT {$page},10";

        if($dbConn->count($m)>0){ 

foreach($dbConn->select($m) as $array){
 
echo '<div class="b"><font color="red">'.iconv_substr($array['name'],0,12,'utf-8').'</font> <a href="style.php?xg=1&id='.$array['id'].'">修改</a></div>';
 
        }
 
 
        }else{echo('暂无样式内容');}

echo '<br/>-<a href="style.php">增加样式</a>';

 }
}else{
echo '<form action="style.php" method="post">
 名称:<br/> <input type="text" name="pb_t"/><br/>
   CSS内容:<br/> <textarea name="pb_nr" cols="35" rows="15"></textarea><br/>
<input name="add" type="submit" value="增加样式">
</form>
-<a href="style.php?xg=1">修改样式</a>
';

        }
require 'foot.tpl';
?>