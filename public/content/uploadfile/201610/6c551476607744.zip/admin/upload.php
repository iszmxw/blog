<?php
session_start();
if($_SESSION['admin']){

       $titles='上传logo';
       include 'head.tpl';

       if(isset($_POST['file'])){

$upload=move_uploaded_file($_FILES["file"]["tmp_name"], $_SERVER['DOCUMENT_ROOT']. ' /logo.gif'); 

           if($upload){echo('成功');}else{echo('失败');}

}else{
echo <<<html
 <form enctype="multipart/form-data" action="upload.php" method="post">
<label for="file">请选择上传的文件</label>
<input type="file" name="file" size="40" />
<br />
<input type="submit" name="submit" value="确定" />
</form> 路径:
html;

}

include 'foot.php';

}else{}
?>
