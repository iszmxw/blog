<?php
session_start();
date_default_timezone_set('PRC');
require './config.php';
require ROOT_T.'/require.php';

if(isset($_GET['id'])==false){exit;}
  $id=(int)$_GET['id'];
  if(!isset($_SESSION['url'.$id])){
     $m= "SELECT * FROM ".DB_QZ."_link WHERE id='".$id."' LIMIT 1";

      $lip="SELECT * FROM ".DB_QZ."_ip ORDER by id DESC LIMIT 1";
 
          $ipget=$dbConn->get_row($lip);
           if(date('Ymd',$ipget['time'])!=date('Ymd',time())){
          $dbConn->query("UPDATE ".DB_QZ."_count SET zf='1',ip='1',zfw=zfw+1,zip=zip+1 WHERE id='1' LIMIT 1");
        $dbConn->query("DELETE FROM ".DB_QZ."_ip");


}
      if($dbConn->count($m)==1){
        $sh=$dbConn->get_row($m);
        if($sh['sh']=='0' and $sh['xd']=='0'){
          $dbConn->query("UPDATE ".DB_QZ."_link SET sh='1',ko=ko+1,time=".time()." WHERE id='".$id."' LIMIT 1");}else{
     $dbConn->query("UPDATE ".DB_QZ."_link SET ko=ko+1,`time`='".time()."' WHERE id='".$id."' LIMIT 1");}
    $getdate="SELECT * FROM ".DB_QZ."_ip WHERE text='链入' && sip='".$_SERVER["REMOTE_ADDR"]."' && lid='".$id."' LIMIT 1";

    if($dbConn->count($getdate)<1){
$insert=array('sip'=>$_SERVER['REMOTE_ADDR'],'lid'=>$id,'time'=>time(),'text'=>'链入');
   $dbConn->insert_array(DB_QZ.'_ip',$insert);
   $dbConn->query("UPDATE ".DB_QZ."_link SET iko=iko+1 WHERE id='".$id."' LIMIT 1");}
$_SESSION['url'.$id]='ailiw';}
}

 header('location:../index.php');
?>