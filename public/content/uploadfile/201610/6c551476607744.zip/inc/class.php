<?php

function ubb(){//今日访问
    $text=' <br><br/>♪～(´ε｀　)首页及自定义页面排版ubb<br/>
年:【year】<br/>月:【month】日:【day】<br/>时:【hour】分:【minute】秒:【second】<br/>
时间:【time】日期:【date】当前:【now】<br/>星期【weekday】来源IP:【comeip】<br/>日IP:【ip】总IP:【zip】<br/>日访问量:【pv】总访问量:【zpv】<br/>
加盟:【add】说明【/add】<br/>留言:【lyb】说明【/lyb】<br/>风格:【style】说明【/style】<br/>定义页:【define=id】说明【/define】<br/>搜索框:【search】关键字【/search】<br/>html实例化:【html】html代码【/html】<br/><br/>文章列表:【wzl=a_b_c】<br/>
*a条数,b字数,c排序(1最新,2最热,3随机)<br/><br/>文章分类列表:【wzll=d_a_b】<br/>*d为文章分类id<br/><br/>友链列表:【linkl=c_a_e】<br/>*c排序(1新收录,2最热,3固链,4最新动态),e行数<br/><br/>
友链分类列表:【linkll=d_a】<br/><br/>♪～(´ε｀　)文章支持的ubb<br/>
html实例化:【html】代码【/html】<br/><br/>*文章和排版都支持html(5)、CSS(3)、JS等代码<br/><br/>'; 
    return $text;
}

function html($matches){
return htmlspecialchars($matches[1]); 

}

function ailierror($error){//提示
   echo '<div class="tip">'.$error.'！<br/></div>';
}

function search($matches){//搜索
//本功能应用由学C开发
  $read='<option value="http://m.baidu.com/s?word=">百度搜索</option>
<option value="http://www.google.com.hk/search?hl=zh-CN&newwindow=1&safe=strict&q=">谷歌搜索</option>
<option value="http://wap.soso.com/sweb/search.jsp?key=">搜搜搜索</option>
<option value="http://wap.sogou.com/web/searchList.jsp?keyword=">搜狗搜索</option>
<option value="http://i.easou.com/s.m?q=">宜搜搜索</option>
<option value="http://page.yicha.cn/p/ps.do?key=">易查搜索</option>
<option value="http://s8.m.taobao.com/munion/search.htm?&pid=mm_32037038_3338621_10825858&ttid=momo_mZPluS1PFWDaKiAoEuJG6Q&q=">淘宝商城</option>
<option value="http://m.360buy.com/ware/search.action?keyword=">京东商城</option>
<option value="http://m.dangdang.com/gw_search.php?key=">当当商城</option>';
    return <<<html
<input type="text" name="content" value="{$matches[1]}"/><br/><select id="select">{$read}</select> <input type="submit" value="搜索" onclick="location.href=document.getElementById('select').value+document.getElementsByName('content')[0].value;" />
html;
}

function comeip(){//来源ip
   return $_SERVER['REMOTE_ADDR'];
}

function pv(){//今日访问
   global $dbConn;
   $q=$dbConn->get_row("SELECT zf FROM ".DB_QZ."_count WHERE id='1' LIMIT 1");
    return $q['zf'];
}

function ip(){//今日访问
   global $dbConn;
   $q=$dbConn->get_row("SELECT ip FROM ".DB_QZ."_count WHERE id='1' LIMIT 1");
    return $q['ip'];
}
 

function zip(){//今日访问
   global $dbConn;
   $q=$dbConn->get_row("SELECT zip FROM ".DB_QZ."_count WHERE id='1' LIMIT 1");
    return $q['zip'];
}
 
function zpv(){//总访问
   global $dbConn;
   $q=$dbConn->get_row("SELECT zfw FROM ".DB_QZ."_count WHERE id='1' LIMIT 1");
   return $q['zfw'];
} 
function dt(){//游客动态
  global $db,$dbConn;
  $q=$dbConn->get_row("SELECT time,zf FROM ".DB_QZ."_count WHERE id='2' LIMIT 1");
  $time=time()-$q['time']; 
  if($time<60 or $time==60){
    $s='秒';$time=$time;
   }elseif($time>60 and $time<3600 or $time==3600){
    $s='分';$time=$time/60;
   }else{
    $s='时';$time=$time/3600;
   }
    return '游客'.ceil($time).$s.'前访问了'.$q['zf'];
}

function article_num($matches){//文章列表
   global $dbConn;
   if($matches[3]=='1'){//最新
$aid='id';$ad='DESC';
   }elseif($matches[3]=='2'){//最热
 $aid='cs';$ad='ASC';
  }elseif($matches[3]=='3'){//随机
 $aid='rand()';$ad='';
 }else{//默认
 $aid='id';$ad='DESC'; 
}
  $q="SELECT * FROM ".DB_QZ."_article ORDER BY ".$aid." ".$ad." LIMIT ".$matches[1];$m='';

  if($dbConn->count($q)>0){
   foreach($dbConn->select($q) as $array){

     $m.='<a href="./system/articleread.php?aid='.$array['id'].'">'.iconv_substr($array['title'],0,$matches[2],'utf-8').'</a>'; 
      }
    return $m;
   }else{return '暂无数据';}
}

function ulink_num($matches){//友链分类列表
  global $dbConn;
  $q="SELECT  id FROM ".DB_QZ."_sort WHERE id='".$matches[1]."' LIMIT 1";

  if($dbConn->count($q)==1){
   $o="SELECT * FROM ".DB_QZ."_link WHERE sortid='".$matches[1]."' and sh='1' ORDER BY iko ASC LIMIT ".($matches[2]-1);

     $z=$dbConn->get_row("SELECT * FROM ".DB_QZ."_link WHERE sortid='".$matches[1]."' and sh='1' ORDER BY ".time()."-time ASC LIMIT 1");
$m='<a href="read.php?kid='.$z['id'].'" target="_blank">'.$z['name'].'</a>';
    if($dbConn->count($o)>0){
      foreach($dbConn->select($o) as $row){
        $m.='<a href="read.php?kid='.$row['id'].'" target="_blank">'.$row['name'].'</a>';
          }
      return $m;
    }else{return '暂无该分类数据';}
  }else{return '暂无该分类';}
}

function ublog_num($matches){//文章分类
  global $dbConn;
  $q="SELECT  name FROM ".DB_QZ."_sort WHERE id='".$matches[1]."' LIMIT 1";

  if($dbConn->count($q)==1){
    $o="SELECT * FROM ".DB_QZ."_article WHERE sortid='".$matches[1]."' ORDER BY id DESC LIMIT ".$matches[2];$m='';

    if($dbConn->count($o)>0){
     foreach($dbConn->select($o) as $row){
      $m.='<a href="./system/articleread.php?aid='.$row['id'].'">'.iconv_substr($row['title'],0,$matches[3],'utf-8').'</a>'; 
       }
     return $m;
    }else{return '暂无该分类数据';}
  }else{return '暂无该分类';}
}

function link_num($matches){//友链列表
 global $dbConn;

 if($matches[2]=='1'){//最新
$aid='id';$ad='DESC'; $wh='';
 }elseif($matches[2]=='2'){//最热
 $aid='iko';$ad='ASC';
 $wh="WHERE sh='1'";
 }elseif($matches[2]=='3'){//随机
 $aid='iko';$ad='ASC';
 $wh="WHERE xd='1'";
 }elseif($matches[2]=='4'){//时间排序
 $aid='".time()."-time';$ad='ASC'; 
 $wh="";}
/*elseif($matches[2]=='5'){
 $aid='ko';$ad='ASC'; 
 $wh="WHERE sh='1'";
 }elseif($matches[2]=='6'){
 $aid='ikt';$ad='ASC';
 $wh="WHERE sh='1'";
 }elseif($matches[2]=='7'){ 
 $aid='iko';$ad='ASC'; 
 $wh="WHERE sh='1'";
 }elseif($matches[2]=='8'){ 
 $aid='iko';$ad='ASC'; 
 $wh="WHERE xd='1'";
//默认
 }*/
else{
 $aid='id';$ad='DESC';
$wh="WHERE sh='1'";
 }
  $q="SELECT * FROM ".DB_QZ."_link ".$wh." ORDER BY ".$aid." ".$ad." LIMIT ".$matches[1];$m='';

   if($dbConn->count($q)>0){
      $i=0;
      foreach($dbConn->select($q) as $array){

       if($matches[2]=='3'){
        $m.='<a href="'.$array['url'].'" target="_blank">'.$array['name'].'</a>';
        }else{
        $m.='<a href="./read.php?kid='.$array['id'].'" target="_blank">'.$array['name'].'</a>';
        }
      $i++;
   if($i==$matches[3]){
     $m.='<br/>';
     $i=0;
    }
  }
  return $m;
 }else{return '暂无该数据';}
}
?>