<?php
class ipclass{
     public $dbConn;
function ip(){
          $ip="SELECT * FROM ".DB_QZ."_ip WHERE sip='".$_SERVER['REMOTE_ADDR']."'";
         if($this->dbConn->count($ip)>0){
           $lip="SELECT * FROM ".DB_QZ."_ip ORDER by id DESC LIMIT 1"; 
          $ipget=$this->dbConn->get_row($lip);
           if(date('Ymd',$ipget['time'])!=date('Ymd',time())){
          $this->dbConn->query("UPDATE ".DB_QZ."_count SET zf='1',ip='1',zfw=zfw+1,zip=zip+1 WHERE id='1' LIMIT 1");
        $this->dbConn->query("DELETE FROM ".DB_QZ."_ip");
     $q=array(
'sip'=>$_SERVER['REMOTE_ADDR'],
'time'=>time());
     $this->dbConn->insert_array(DB_QZ.'_ip',$q);} 
          }else{
            $this->dbConn->query("UPDATE ".DB_QZ."_count SET ip=ip+1,zip=zip+1 WHERE id='1' LIMIT 1");

     $q=array(
'sip'=>$_SERVER['REMOTE_ADDR'],
'time'=>time());
     $this->dbConn->insert_array(DB_QZ.'_ip',$q);
 
  }
 }

function pv(){
   if(!isset($_SESSION["sy"])){

     $this->dbConn->query("UPDATE ".DB_QZ."_count SET zf=zf+1,zfw=zfw+1 WHERE id='1' LIMIT 1");
   $_SESSION["sy"]="t2dt.com";
  }
 }
}