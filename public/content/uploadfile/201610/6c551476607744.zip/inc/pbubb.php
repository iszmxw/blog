<?php
class ubb{
   public $string;

function pbubb($string){
    $weekend=array('日','一','二','三','四','五','六');
  $string=str_replace("[year]
",date("Y"),$string);
  $string=str_replace("[month]",date("m"),$string);
  $string=str_replace("[day]",date("d"),$string);
  $string=str_replace("[hour]
",date("H"),$string);
  $string=str_replace("[minute]
",date("i"),$string);
  $string=str_replace("[second]
",date("s"),$string);
  $string=str_replace("[time]",date("H:i:s"),$string);
  $string=str_replace("[date]",date("Y-m-d"),$string);
  $string=str_replace("[now]",date("Y-m-d H:i:s"),$string);
  $string=str_replace('[weekday]',$weekend[date('w',time())],$string);
   $string=str_replace('[root_path]',ROOT_T,$string);
   $string=preg_replace_callback('/\[wzl=(\d+)_(\d+)_(\d{1})\]/',"article_num",$string);
   $string=preg_replace_callback('/\[linkl=(\d+)_(\d{1})_(\d{1})\]/',"link_num",$string);
   $string=preg_replace_callback('/\[wzll=(\d+)_(\d{1,})_(\d{1,})\]/u',"ublog_num",$string);
  $string=preg_replace_callback('/\[linkll=(\d+)_(\d+)\]/u',"ulink_num",$string);
  $string=preg_replace('/\[linkn=(\d+)\]([0-9a-zA-Z\x{4e00}-\x{9fa5}]{2})\[\/linkn\]/u','<a href="system/linktype.php?id=\\1">\\2</a>',$string);
  $string=preg_replace_callback('/\[linkdt\]/',"dt",$string);
  $string=preg_replace('/\[add\]([0-9a-zA-Z\x{4e00}-\x{9fa5}]*)\[\/add\]/u',"<a href='system/linkadd.php'>\\1</a>",$string);
  $string=preg_replace('/\[lyb\]([0-9a-zA-Z\x{4e00}-\x{9fa5}]*)\[\/lyb\]/u',"<a href='system/lyblist.php'>\\1</a>",$string);
  $string=preg_replace_callback('/\[comeip\]/',"comeip",$string);
  $string=preg_replace_callback('/\[ip\]/',"ip",$string);
  $string=preg_replace_callback('/\[pv\]/',"pv",$string);
  $string=preg_replace_callback('/\[zip\]/',"zip",$string);
  $string=preg_replace_callback('/\[zpv\]/',"zpv",$string);
  $string=preg_replace_callback('/\[ubb\]/',"ubb",$string); 
  $string=preg_replace_callback('/\[search\]([0-9a-zA-Z\x{4e00}-\x{9fa5}]*)\[\/search\]/u',"search",$string);
  $string=preg_replace('/\[define=([0-9]{1,})\](.*)\[\/define\]/iUs',"<a href='pbmod.php?id=\\1'>\\2</a>",$string);
  $string=preg_replace('/\[style\]([0-9a-zA-Z\x{4e00}-\x{9fa5}]*)\[\/style\]/u',"<a href='style.php'>\\1</a>",$string);
      $string=preg_replace_callback('/\[html\](.*)\[\/html]/',"html",$string);
      

return $string;
 }

}
?>