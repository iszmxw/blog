<?php
class template{
 var $template,$cache;
 public $config=array('right' => '{','left'=> '}','var'=> 'N');

function __construct($template,$cache){
     $this->template=$template;
     $this->cache=$cache;
}

function display($temp){

 $Right=$this->config["right"]."\s*";
$Left="\s*".$this->config["left"];
$var=$this->config["var"];
$pattern = array (
 '/'.$Right.'G\$(\w+)\[(\w+)\]'.$Left.'/',
 '/'.$Right.'G\$(\w+)'.$Left.'/',
 '/'.$Right.'\$(\w+)\[(\w+)\]'.$Left.'/',
 '/'.$Right.'\$(\w+)'.$Left.'/', 
 '/'.$Right.'if\s?G\$(\w+)\[(\w+)\]'.$Left.'/Ui',
 '/'.$Right.'if\s*G\$(.+)'.$Left.'/Ui',
 '/'.$Right.'else\s?if\s?G\$(\w+)\[(\w+)\]'.$Left.'/Ui',
 '/'.$Right.'else\s?'.$Left.'/Ui',
 '/'.$Right.'for\s?((.+,.+,.+))'.$Left.'/Ui',
 '/'.$Right.'while\s?((.+))'.$Left.'/Ui',
 '/'.$Right.'(foreach|loop)\s?G\$(.+) as (\$.+)'.$Left.'/Ui',
 '/'.$Right.'(foreach|loop)\s?(\$.+) as (\$[^=>]+)\s?=>\s?(\$\w+)'.$Left.'/Ui',
 '/'.$Right.'\/(if|for|while)'.$Left.'/Ui',
 '/'.$Right.'end(if|for|while)'.$Left.'/Ui',
 '/'.$Right.'\/(loop|foreach)'.$Left.'/Ui',
 '/'.$Right.'end(loop|foreach)'.$Left.'/Ui',
 '/'.$Right.'([a-zA-Z_\x7f-\xff][a-zA-Z0-9_\x7f-\xff]*)\s?\(([^\)]*)\)'.$Left.'/Ui',
 '/'.$Right.'([a-zA-Z_\x7f-\xff][a-zA-Z0-9_\x7f-\xff]*)\s?\((\s?[a-zA-Z_\x7f-\xff][a-zA-Z0-9_\x7f-\xff]*\s?\([^\)]*\)\s?)\)'.$Left.'/Ui');
 $replace = array (
'<?php
echo $GLOBALS["${1}"]["${2}"];
?>',
 '<?php
echo $GLOBALS["${1}"];
?>', 
 '<?php
echo $${1}["${2}"];
?>',
 '<?php
echo $${1};
?>', 
 '<?php if($GLOBALS["${1}"]["${2}"]){ ?>',
 '<?php if($GLOBALS["${1}"]){ ?>',
 '<?php }elseif($GLOBALS["${1}"]["${2}"]){ ?>',
 '<?php }else{ ?>',
 '<?php for(${1}){ ?>',
 '<?php while(${1}){ ?>',
 '<?php if(is_array($GLOBALS["${2}"])){ foreach($GLOBALS["${2}"] as ${3}){ ?>',
 '<?php if(is_array($GLOBALS["${2}"])){ foreach( $GLOBALS["${2}"] as ${3} => ${4} ){ ?>',
 '<?php } ?>',
 '<?php } ?>',
 '<?php } } ?>',
 '<?php } } ?>',
 '<?php echo ${1}(${2}); ?>',
 '<?php echo ${1}(${2}); ?>',
 );

$display=preg_replace($pattern,$replace,file_get_contents($this->template.$temp));
$displays=file_put_contents($this->cache.$temp,$display);
//print_r($GLOBALS);
include $this->cache.$temp;
   return true;
 }

 private function replace($str){
//问题，以后处理
//if(PHP_VERSION >= 6 or get_magic_quotes_gpc())
$str=stripslashes($str);
 $pattern=array(
"/\[(\w+)\]/U",
'/\$(\w+)/',
);
 $replace=array(
'["${1}"]',
'\$${1}',
);
 $str=preg_replace($pattern,$replace,$str);
 return $this->config["right"].$str.$this->config["left"];
 }
 
}