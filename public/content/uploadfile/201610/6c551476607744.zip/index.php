<?php

if(!file_exists('config.php')){
//跳转安装
 echo str_replace("{title}","版权申明",file_get_contents("html.txt")).'本程序为商业程序，非授权网址禁止安装本程序，非法安装带来后果和法律责任，与官方无关！<br/>
<a href="install.php">我同意，进去安装</a>';
 
exit();
  }else{
}
require './config.php';
require ROOT_T.'/require.php';

 $titl=$dbConn->get_row("SELECT title FROM ".DB_QZ."_www WHERE id='1' LIMIT 1");$title=$titl['title'];
 
require ROOT_T.'/head.tpl';

     $q="SELECT sypb FROM ".DB_QZ."_pb WHERE id='1' LIMIT 1";

      $sypb=$dbConn->get_row($q);

echo htmlspecialchars_decode(stripslashes($pbubb->pbubb($sypb['sypb'])));

require ROOT_T.'/inc/ipclass.php';
  $ip=new ipclass();
  $ip->dbConn=& $dbConn;
  $ip->ip();$ip->pv();
require ROOT_T.'/foot.tpl';
?>