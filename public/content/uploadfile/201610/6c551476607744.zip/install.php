<?php

echo str_replace("{title}","安装",file_get_contents("html.txt"));
 
if(!file_exists('./config.php')){}else{die('安装生成文件已存在！');}

if(isset($_POST["submit"])){

  require './inc/mysql.class.php';

  $dbConn=new dbConn($_POST['host'],$_POST['user'],$_POST['pass'],$_POST['test']);

   $file=str_replace('DBQZ',$_POST['qz'],
  file_get_contents('mysql.sql'));
   $file=str_replace('\n','',$file);

    $explode=explode(';<br/>;',$file);

    $a=0;$b=0;$error="";

     for($i=0;$i<count($explode)-1;$i++){

       $query=$dbConn->query($explode[$i]);

        if($query){$a++;}else{$b++;

         $error.=$explode[$i].'<br/>';}

         }
           echo '成功执行'.$a.'条SQL，失败'.$b.'条，总计'.$i.'条<br/>失败SQL语句：'.$error.'<hr/>';

       $text='<?php
define("ROOT_T",dirname(__FILE__));
define("DB_QZ","'.$_POST['qz'].'");
define("DB_HOST","'.$_POST['host'].'");
define("DB_USER","'.$_POST['user'].'");
define("DB_PASS","'.$_POST['pass'].'");
define("DB_NAME","'.$_POST['test'].'");
?>';
 if(!file_put_contents('./config.php',$text)){echo '文件写入失败！<br/>可能原因：该空间不支持读写或者不支持file_put_contents函数。请联系空间配置<br/>';}
 
echo '安装成功<br/>进入<a href="../">网站首页</a>｜｜<a href="../admin/">后台管理</a><br/>系统默认登录<br/>账户:admin,密码:123456';
   }else{

echo <<<html
<安装前请阅读下方
的文字说明><br/>
<form action="install.php" method="post">
     
数据库地址:<br/><input type="text" name="host" placeholder="localhost或者mysql.主域名" /><br/>       
数据库名称:<br/><input type="text" name="test" placeholder="请确定数据库已存在" /><br/>       
数据库用户:<br/><input type="text" name="user" placeholder="数据库user" /><br/>       
数据库密码:<br/><input type="text" name="pass" placeholder="密码" /><br/>       
数据表前缀:<br/><input type="text" name="qz" placeholder="可以是任意的字符,建议为数字或者字母" /><br/>       
选择操作项:<input type="submit" value="快速安装" name="submit"/></form>
<一>安装必看(环境支持)：<br/>
1.需要支持文件读写操作，否则会出现模板不能解析(很多页面会“乱码”)<br/>
2.需要PHP环境和MySQL数据库<br/>
3.v1.6以下的版本需要PHP短标签支持<br/>
<二>在线升级(说明)<br/>
一直没有时间做这个功能，在v1.5里增加了在线升级提示，如果有新版本就会在后台显示，但是在官方出现维护时可能也会出现，有时间可以关注下官方动态<br/>
<三>听风者(艾黎团队)<br/>
艾黎于2014年08月03日成立了团队--听风者，并改名为听风者•艾黎<br/>
html;
}

echo '</body></html>';
?>