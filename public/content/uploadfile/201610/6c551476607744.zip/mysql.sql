CREATE TABLE `DBQZ_admin` (\n  `id` int(5) NOT NULL AUTO_INCREMENT,\n  `name` char(24) NOT NULL,\n  `pass` char(64) NOT NULL,\n  `way` char(20) NOT NULL,\n  `bmail` char(100) NOT NULL,\n  `email` char(100) NOT NULL,\n  `epass` char(64) NOT NULL,\n  `head` text NOT NULL,\n  PRIMARY KEY (`id`)\n) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;<br/>;
CREATE TABLE `DBQZ_article` (\n  `id` int(8) NOT NULL AUTO_INCREMENT,\n  `title` char(200) NOT NULL,\n  `sortid` char(24) NOT NULL,\n  `uid` int(5) NOT NULL,\n  `text` text NOT NULL,\n  `cs` int(5) NOT NULL,\n  `time` int(11) NOT NULL,\n  PRIMARY KEY (`id`)\n) ENGINE=MyISAM DEFAULT CHARSET=utf8;<br/>;
CREATE TABLE `DBQZ_count` (\n  `id` int(8) NOT NULL AUTO_INCREMENT,\n  `zf` int(6) NOT NULL,\n  `zfw` int(11) NOT NULL,\n  `ip` int(6) NOT NULL,\n  `zip` int(11) NOT NULL,\n  `time` int(11) NOT NULL,\n  PRIMARY KEY (`id`)\n) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;<br/>;
CREATE TABLE `DBQZ_ip` (\n  `id` int(5) NOT NULL AUTO_INCREMENT,\n  `sip` char(30) NOT NULL,\n  `lid` int(9) NOT NULL,\n  `text` char(8) NOT NULL,\n  `time` int(11) NOT NULL,\n  PRIMARY KEY (`id`)\n) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;<br/>;
CREATE TABLE `DBQZ_link` (\n  `id` int(5) NOT NULL AUTO_INCREMENT,\n  `lock` int(2) NOT NULL,\n  `name` char(8) NOT NULL,\n  `qname` char(15) NOT NULL,\n  `sortid` int(8) NOT NULL,\n  `logo` char(62) NOT NULL,\n  `url` char(164) NOT NULL,\n  `link` int(11) NOT NULL,\n  `js` char(164) NOT NULL,\n  `xd` int(2) NOT NULL,\n  `sh` int(2) NOT NULL,\n  `kt` int(5) NOT NULL,\n  `ko` int(5) NOT NULL,\n  `ikt` int(5) NOT NULL,\n  `iko` int(5) NOT NULL,\n  `time` int(11) NOT NULL,\n  PRIMARY KEY (`id`)\n) ENGINE=MyISAM DEFAULT CHARSET=utf8;<br/>;
CREATE TABLE `DBQZ_lyb` (\n  `id` int(8) NOT NULL AUTO_INCREMENT,\n  `name` char(8) NOT NULL,\n  `title` char(15) NOT NULL,\n  `text` text NOT NULL,\n  `zt` char(4) NOT NULL,\n  `time` int(11) NOT NULL,\n  PRIMARY KEY (`id`)\n) ENGINE=MyISAM DEFAULT CHARSET=utf8;<br/>;
CREATE TABLE `DBQZ_msg` (\n  `id` int(5) NOT NULL AUTO_INCREMENT,\n  `name` char(8) NOT NULL,\n  `uid` int(5) NOT NULL,\n  `text` text NOT NULL,\n  `zt` char(3) NOT NULL,\n  `time` int(11) NOT NULL,\n  PRIMARY KEY (`id`)\n) ENGINE=MyISAM DEFAULT CHARSET=utf8;<br/>;
CREATE TABLE `DBQZ_pb` (\n  `id` int(8) NOT NULL AUTO_INCREMENT,\n  `sypb` text NOT NULL,\n  `top` text NOT NULL,\n  `foot` text NOT NULL,\n  PRIMARY KEY (`id`)\n) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;<br/>;
CREATE TABLE `DBQZ_sort` (\n  `id` int(8) NOT NULL AUTO_INCREMENT,\n  `name` char(20) NOT NULL,\n  `lock` char(12) NOT NULL,\n  PRIMARY KEY (`id`)\n) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;<br/>;
CREATE TABLE `DBQZ_style` (\n  `id` int(5) NOT NULL AUTO_INCREMENT,\n  `text` text NOT NULL,\n  `name` char(15) NOT NULL,\n  PRIMARY KEY (`id`)\n) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;<br/>;
CREATE TABLE `DBQZ_www` (\n  `id` int(8) NOT NULL AUTO_INCREMENT,\n  `title` text NOT NULL,\n  `gjz` text NOT NULL,\n  `ms` text NOT NULL,\n  `host` char(50) NOT NULL,\n  `name` char(8) NOT NULL,\n  `qname` char(15) NOT NULL,\n  `js` char(200) NOT NULL,\n  PRIMARY KEY (`id`)\n) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;<br/>;
INSERT INTO `DBQZ_admin`
 VALUES("1","admin","123456","","","","","这首歌送给年少时的我们.[br/]希望你一切都好!");<br/>;
INSERT INTO `DBQZ_count`
 VALUES("1","1","1","1","1","0");<br/>;
INSERT INTO `DBQZ_ip`
 VALUES("1","127.0.0.1","0","","1402329772");<br/>;
INSERT INTO `DBQZ_pb`
 VALUES("1"," &lt;style&gt;
.vintage{color: #fafafa;
letter-spacing: 0;
text-shadow: 0px 1px 0px #999, 0px 2px 0px #888, 0px 3px 0px #777, 0px 4px 0px #666, 0px 5px 0px #555, 0px 6px 0px #444, 0px 7px 0px #333, 0px 8px 7px #001135 }
&lt;/style&gt;[ubb]
&lt;h1 class=&quot;vintage&quot;&gt;艾黎网址大全&lt;/h1&gt;
[search]艾黎导航[/search]&lt;div class=&quot;c&quot;&gt;&lt;font color=&quot;#000&quot;&gt;【热站动态】&lt;/font&gt;&lt;br/&gt;&lt;/div&gt;
&lt;div class=&quot;dtlink&quot;&gt;[linkl=10_4_5]&lt;/div&gt;
 &lt;div class=&quot;c&quot;&gt;&lt;font color=&quot;#000&quot;&gt;【新站热推】一个量自动审核&lt;/font&gt;&lt;br/&gt;&lt;/div&gt;
&lt;div class=&quot;dtlink&quot;&gt;[linkl=10_1_5]&lt;/div&gt; 
&lt;div class=&quot;c&quot;&gt;&lt;font color=&quot;#000&quot;&gt;【热门分类】有量第一，无量沉底&lt;/font&gt;&lt;/div&gt;
&lt;div class=&quot;type&quot;&gt;&lt;b&gt;
[linkn=6]综合[/linkn]&lt;/b&gt;&lt;m&gt;[linkll=6_4]&lt;/m&gt;&lt;br/&gt;
&lt;b&gt;[linkn=7]图片[/linkn]&lt;/b&gt;&lt;m&gt;[linkll=7_4]&lt;/m&gt;&lt;br/&gt;
&lt;b&gt;[linkn=8]社区[/linkn]&lt;/b&gt;&lt;m&gt;[linkll=8_4]&lt;/m&gt;&lt;br/&gt;
&lt;b&gt;[linkn=9]论坛[/linkn]&lt;/b&gt;&lt;m&gt;[linkll=9_4]&lt;/m&gt;&lt;br/&gt;
&lt;b&gt;[linkn=10]小说[/linkn]&lt;/b&gt;&lt;m&gt;[linkll=10_4]&lt;/m&gt;&lt;br/&gt;
&lt;b&gt;[linkn=11]破解[/linkn]&lt;/b&gt;&lt;m&gt;[linkll=11_4]&lt;/m&gt;&lt;br/&gt;
&lt;b&gt;[linkn=12]导航[/linkn]&lt;/b&gt;&lt;m&gt;[linkll=12_4]&lt;/m&gt;&lt;br/&gt;
&lt;b&gt;[linkn=13]建站[/linkn]&lt;/b&gt;&lt;m&gt;[linkll=13_4]&lt;/m&gt;&lt;br/&gt;
&lt;b&gt;[linkn=14]其他[/linkn]&lt;/b&gt;&lt;m&gt;[linkll=14_4]&lt;/m&gt;&lt;/div&gt;
&lt;div class=&quot;c&quot;&gt;&lt;font color=&quot;#000000&quot;&gt;【合作伙伴】&lt;/font&gt;&lt;br/&gt;&lt;/div&gt;
&lt;div class=&quot;dtlink&quot;&gt;[linkl=16_3_4]&lt;/div&gt;
 &lt;div class=&quot;c&quot;&gt;&lt;font color=&quot;#000000&quot;&gt;【网站合作说明】&lt;a href=&quot;http://35230.wodemo.com&quot;&gt;笑忘书代码&lt;/a&gt;&lt;/font&gt;&lt;br/&gt;&lt;/div&gt; 
&lt;div class=&quot;list&quot;&gt;[wzll=3_3_20]
&lt;/div&gt;
&lt;div class=&quot;c&quot;&gt;&lt;font color=&quot;#000000&quot;&gt;【站务中心】&lt;br/&gt;&lt;/div&gt;&lt;div class=&quot;type&quot;&gt;&lt;b&gt;[add]收录[/add]&lt;/b&gt;&lt;b&gt;[lyb]留言[/lyb]&lt;/b&gt;&lt;b&gt;[define=2]ubb手册[/define]&lt;/b&gt;&lt;b&gt;[style]换肤[/style]&lt;/b&gt;&lt;br/&gt;&lt;/div&gt;&lt;div class=&quot;user&quot;&gt;主域名:&lt;font color=&quot;red&quot;&gt;ailiw.cn&lt;/font&gt;
&lt;br/&gt;备域名:&lt;font color=&quot;red&quot;&gt;t2dt.tk&lt;/font&gt;/&lt;font color=&quot;red&quot;&gt;jz.cnmsidc.com&lt;/font&gt;&lt;br/&gt;Copyright ©2013-2014 艾黎网&lt;br/&gt;&lt;/div&gt; 
weekday])","&lt;div class=&quot;nav&quot;&gt;&lt;marquee scrollAmount=6 width=300&gt;&lt;font color=&quot;red&quot;&gt;公告：网站维护，程序升级中！&lt;/font&gt;&lt;/marquee&gt;&lt;br/&gt;&lt;/div&gt;
"," &lt;div class=&quot;foot&quot;&gt;艾黎域名:&lt;a href=&quot;&quot;&gt;ailiw.cn&lt;/a&gt;|&lt;a class=&quot;right but&quot; 
href=&quot;ext:add_favorite&quot;&gt;书签&lt;/a&gt;&lt;br/&gt;合作QQ&lt;a target=&quot;_blank&quot; href=&quot;http://wpa.qq.com/mserd?v=3&amp;uin=248114365&amp;site=qq&amp;menu=yes&quot;&gt;&lt;img border=&quot;0&quot; src=&quot;http://wpa.qq.com/pa?p=2:248114365:52&quot; alt=&quot;点击这里给我发消息&quot; title=&quot;点击这里给我发消息&quot;/&gt;&lt;/a&gt;248114365&lt;br/&gt;
小艾报时:[now] ([weekday])");<br/>;
INSERT INTO `DBQZ_pb`
 VALUES("2","","ubb使用手册","&lt;br&gt;&lt;br/&gt;♪～(´ε｀　)首页及自定义页面排版ubb&lt;br/&gt;
年:【year】&lt;br/&gt;月:【month】日:【day】&lt;br/&gt;时:【hour】分:【minute】秒:【second】&lt;br/&gt;
时间:【time】日期:【date】当前:【now】&lt;br/&gt;星期【weekday】来源IP:【comeip】&lt;br/&gt;日IP:【ip】总IP:【zip】&lt;br/&gt;日访问量:【pv】总访问量:【zpv】&lt;br/&gt;
加盟:【add】说明【/add】&lt;br/&gt;留言:【lyb】说明【/lyb】&lt;br/&gt;风格:【style】说明【/style】&lt;br/&gt;定义页:【define=id】说明【/define】&lt;br/&gt;搜索框:【search】关键字【/search】&lt;br/&gt;html实例化:【html】html代码【/html】&lt;br/&gt;&lt;br/&gt;文章列表:【wzl=a_b_c】&lt;br/&gt;
*a条数,b字数,c排序(1最新,2最热,3随机)&lt;br/&gt;&lt;br/&gt;文章分类列表:【wzll=d_a_b】&lt;br/&gt;*d为文章分类id&lt;br/&gt;&lt;br/&gt;友链列表:【linkl=c_a_e】&lt;br/&gt;*c排序(1新收录,2最热,3固链,4最新动态),e行数&lt;br/&gt;&lt;br/&gt;
友链分类列表:【linkll=d_a】&lt;br/&gt;&lt;br/&gt;♪～(´ε｀　)文章支持的ubb&lt;br/&gt;
html实例化:【html】代码【/html】&lt;br/&gt;&lt;br/&gt;*文章和排版都支持html(5)、CSS(3)、JS等代码&lt;br/&gt;&lt;br/&gt;");<br/>;
INSERT INTO `DBQZ_sort`
 VALUES("1","日志","article");<br/>;
INSERT INTO `DBQZ_sort`
 VALUES("2","情感","article");<br/>;
INSERT INTO `DBQZ_sort`
 VALUES("3","教程","article");<br/>;
INSERT INTO `DBQZ_sort`
 VALUES("4","程序","article");<br/>;
INSERT INTO `DBQZ_sort`
 VALUES("5","生活","article");<br/>;
INSERT INTO `DBQZ_sort`
 VALUES("6","综合","link");<br/>;
INSERT INTO `DBQZ_sort`
 VALUES("7","图片","link");<br/>;
INSERT INTO `DBQZ_sort`
 VALUES("8","社区","link");<br/>;
INSERT INTO `DBQZ_sort`
 VALUES("9","论坛","link");<br/>;
INSERT INTO `DBQZ_sort`
 VALUES("10","小说","link");<br/>;
INSERT INTO `DBQZ_sort`
 VALUES("11","破解","link");<br/>;
INSERT INTO `DBQZ_sort`
 VALUES("12","网址","link");<br/>;
INSERT INTO `DBQZ_sort`
 VALUES("13","建站","link");<br/>;
INSERT INTO `DBQZ_sort`
 VALUES("14","其他","link");<br/>;
INSERT INTO `DBQZ_style`
 VALUES("1","body{
background:#DDD;
margin:0 auto;
padding:0;
width:320px;
line-height:200%;
font-size:16px;
}
a:link, a:visited, a:hover, a:active {
	text-decoration:none;color:#0095ff;
	
}
/*导航栏样式*/
.a,.b,.c{
border:1px solid #FFF;
border-radius:6px;
color:#000;
text-shadow:1px 1px 1px #FFF;
box-shadow:0px 2px 2px #999;}
.a div,.b div,.c div,.view div,.user div{width:4px;height:20px;margin:0 5px;font-size:0px;
border-radius:1px;display:inline;}
.a a,.b a,.c a{color:#FFF;text-shadow:1px 1px 1px #000;}
/*分别设置背景色*/
.a{background:rgba(125,220,255,1);}
.a div,.user div{background:#3A3;}
.b{background:rgba(234,110,25,1);}
.b div,.view div{background:#09E;}
.c{background:#09E;}
.c div{background:rgba(65,210,25,1);}
/*提示*/
.tip{
background:#999;border:1px solid #777;color:#eee;}
/*底部样式*/
.foot{
background:#666;color:#AAA;
border-top:2px solid #DDD;box-shadow:0px -2px 2px #AAA;text-shadow:1px 1px 1px #222;}
.foot a{color:#FFF;}
/*文章页面*/
.wztitle,.wzview{font-size:24px;margin:8px 0;line-height:200%;}
.wztitle{position:fixed;}
.wztime{font-size:12px;color:#999;text-align:right;float:right;padding:0 0 0 8px;;}
.about{
width:100%
border:2px outset #000;
font-size:13pt;
text-align:center;
background:#e6e6e6;
margin-top:10px;
padding-top:5px;
}
.about a{
color:green;
margin:1px 5px 1px 5px;
}
.article-title{
line-height:25pt;
font-size:18pt;
background:orange;
border-radius:5px;
color:#fff;
padding-left:10px;
}
.article-list{
line-height:25px;
}
.article-list a{
display:inline-block;
border-bottom:1px dashed green;
width:97%;
font-size:15pt;
color:#000;
margin-left:5px;
}

.usercon{background:#EEE;color:#333;margin:0;margin:2px 6px 8px 6px;padding:5px 5px;border:1px solid #FFF;border-top:none;border-radius:0px 0px 8px 8px;}
.tag{background:#38669F;color:#FFF;display:inline-block;border:1px solid #FFF;margin:5px 4px;padding:0px 12px;box-shadow:1px 1px 3px #999;border-radius:4px;
}
/*首页友链样式*/
.dtlink a,.type m a{color:#444;
background:#EEE;
border:1px solid #FFF;
display:inline-block;padding:0 11px;
margin:5px 4px;
box-shadow:2px 2px 1px #999;
}
.type b,.tag{background:#38669F;color:#FFF;display:inline-block;border:1px solid #FFF;box-shadow:1px 1px 3px #999;border-radius:4px;
}
.tag{margin:5px 4px;padding:0px 12px;}
.type b{margin:5px 0px;padding:2px 8px;}
.type b a{color:#FF0;}
 
/*文本框、输入框、按钮*/ 
textarea{border:1px solid #FFF;background:#DFDFDF;width:96%;box-shadow:0px 0px 5px #000;}
input[type=text],input[type=password]{
border:1px solid #00c0ff;
color:#00c0ff;
border-radius:5px;
height:30px;
width:240px;
}
input[type=submit]{
background:#00c0ff;
height:28px;
border:1px outset #e4e4e4;
}
/*友链分类列表样式*/
.list{
line-height:25px;
width:100%;
}
.list a{
line-height:25px;
color:#000;
font-size:15pt;
padding-left:7px;
border-bottom:1px dashed #61d600;
font-size:15pt;
width:97%;
display:inline-block;
text-decoration:none;
padding-left:7px;
color:#0086ff;
text-shadow:2px 1px 1px #000;
}
.page{
margin-top:10px;
background:orange;
border-radius:5px;
color:#fff;
font-size:15pt;
}
.page a{
font-size:15ptpt;
text-decoration:none;
color:#00ffc0;
border:2px outset #00ffc0;
padding:2px 5px 2px 5px;
margin-left:10px;}
.title{
background:red;
line-height:30px;
font-size:16pt;
color:#fff;
border-radius:5px;
text-shadow:-2px 3px 1px #000;
}
.nv{
margin-top:10px;
border-top:1px solid #a7a7a7;
font-size:15pt;
text-align:center;
line-height:25pt;
}
.nv a{
font-size:15pt;
background:orange;
color:#fff;
border:2px outset #e4e4e4;
margin-left:10px;
text-decoration:none;
padding:3px 5px 3px 5px;
}
.liubai{
margin-top:40px;
}","水木易安&amp;唯一");<br/>;
INSERT INTO `DBQZ_www`
 VALUES("1","网站标题","网站关键字","网站描述","","简称","全称","简介");<br/>;
