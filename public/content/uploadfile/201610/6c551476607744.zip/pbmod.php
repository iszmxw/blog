<?php

if(isset($_GET['id'])==false){exit;}
  $id=(int)$_GET['id'];
  if($id==1 or $id<1){exit;}
  require './config.php';
  require ROOT_T.'/require.php';

  $z="SELECT top,foot FROM ".DB_QZ."_pb WHERE id='".$id."' LIMIT 1";

  if($dbConn->count($z)==1){
    $pbmod=$dbConn->get_row($z);
    $text=$pbmod['foot'];
    $title=$pbmod['top'];
     require ROOT_T.'/head.tpl';
   echo htmlspecialchars_decode($pbubb->pbubb($text));
     require ROOT_T.'/foot.tpl';
 }
?>