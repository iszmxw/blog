<?php
$title='收录站点';
require '../config.php';
require ROOT_T.'/require.php';
require ROOT_T.'/head.tpl';

  if(isset($_POST['submit'])==TRUE){

     $name=$dbConn->escape(
htmlspecialchars($_POST['name']));
     $qname=$dbConn->escape(
htmlspecialchars($_POST['qname'])); 
     $nam=preg_match('/^[a-zA-Z0-9\x{4e00}-\x{9fa5}]{2}$/u',$name);
     $qnam=preg_match('/^[a-zA-Z0-9\x{4e00}-\x{9fa5}]{4,8}$/u',$qname);
    $url=preg_match('/^(http:\/\/)([a-z0-9A-Z]{1,62}\.)*[a-zA-Z]{2,62}/Uis',$_POST['url']);
    $head=$dbConn->escape(
htmlspecialchars($_POST['head']));
    $lx=preg_match('/^([1-9])[0-9]{4,10}/',$_POST['lx']);

 if($nam && $qnam && $url && $lx ){
   
$sql="SELECT * FROM ".DB_QZ."_link WHERE `name`='".$name."' and `url`='".$_POST["url"]."' LIMIT 1";
    if($dbConn->count($sql)==1){exit('该数据已存在');}
     $q=array('name'=>$name,'qname'=>$qname,'sortid'=>(int)$_POST['fl'],'url'=>$_POST['url'],'js'=>$head,'link'=>$_POST['lx'],'xd'=>'0','sh'=>'0','ko'=>'0','kt'=>'0','iko'=>'0','ikt'=>'0','time'=>time()); 

        $if=$dbConn->insert_array(DB_QZ.'_link',$q);

        $count=$dbConn->get_row('SELECT id FROM '.DB_QZ.'_link ORDER BY id DESC LIMIT 1');

          if($if){
$v=$dbConn->get_row("SELECT * FROM ".DB_QZ."_www WHERE id='1' LIMIT 1");

     echo '恭喜您，申请成功！<br/>简称:<span color=red>'.$v['name'].'</span><br/>全称:<span color=red>'.$v['qname'].'</span><br/>简介: '.$v['js'].'<br/>回链:<input type="text" size="23" id="input" value="http://'.$_SERVER['HTTP_HOST'].'/comeurl.php?id='.$count['id'].'"/>';}else{echo '申请失败';}
  }else{echo '填写不合法';} 
}
else{

  $m= "SELECT * FROM ".DB_QZ."_sort WHERE `lock`='link' ORDER BY `id` ASC";
  $for=$dbConn->select($m);
  $count='SELECT id FROM '.DB_QZ.'_link ORDER BY id DESC LIMIT 1';
   if($dbConn->count($count)>0){
    $count=$dbConn->get_row($count);
    $count=$count['id'];
     }
    $count=(int)$count+1;
    $url='http://'.$_SERVER['HTTP_HOST'].'/comeurl.php?id='.$count;
    $template=new template('../template/system','../cache/system');
    $template->display('/linkadd.html');
}
require ROOT_T.'/foot.tpl';
?>