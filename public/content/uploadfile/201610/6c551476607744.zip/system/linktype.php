<?php

if(isset($_GET['id'])==false){exit;}
$id=(int)$_GET["id"];
require '../config.php';
require ROOT_T.'/require.php';

$getname=$dbConn->get_row("SELECT name FROM ".DB_QZ."_sort WHERE `id`='".$id."' LIMIT 1");
  $title=$getname['name'];
require ROOT_T.'/head.tpl';

   if(isset($_GET["page"])){
     $page=(int)$_GET["page"];
    }else{
     $page=1;
    } 
    $size=($page-1)*10;
    $q= "SELECT * FROM ".DB_QZ."_link WHERE `sortid`='".$id."'";
    $m=$q." ORDER BY `time` DESC LIMIT ".$size.",10";
    $for=$dbConn->select($m); 
    $count=$dbConn->count($q);
    $num=ceil($count/10);
     $pageNext=$page+1;
     $pageFront=$page-1;
    if($page<$num and $page<2){
      $pre=true;
$next=false;$front=false;
     }elseif($page>1 and $page<$num){
      $next=true;
$pre=false;$front=false;
     }elseif($page==$num and $page>1){
         $next=false;
$pre=false;$front=true;
     }else{
        $next=false;
$pre=false;$front=false;
    }
 
 $template=new template('../template/system','../cache/system'); 
    $template->display('/linktype.html'); 
require ROOT_T.'/foot.tpl';
?>