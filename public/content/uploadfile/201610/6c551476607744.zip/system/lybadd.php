<?php

$title='留言';
require '../config.php';
require ROOT_T.'/require.php';
require ROOT_T.'/head.tpl';

if(isset($_POST['pb'])==TRUE){
 if($_POST['pb_nr']!='' and $_POST['pb_t']!='' and $_POST['pb_f']!=''){
  if(isset($_SESSION["l"])){
    if($_SESSION["l"]>time()){exit("留言过快，请稍候……");}
     }else{
       $q=array(
'name'=>$dbConn->escape(htmlspecialchars($_POST["pb_nr"])),'title'=>$dbConn->escape(htmlspecialchars($_POST["pb_t"])),'text'=>$dbConn->escape(htmlspecialchars($_POST["pb_f"])),'zt'=>'未','time'=>time());

    $insert=$dbConn->insert_array(DB_QZ.'_lyb',$q);
     if($insert){$echo='留言成功';
     }else{$echo='留言失败';}
ailierror($echo);

   $_SESSION["l"]=time()+120;
  }

 }else{echo '输入不能为空!<br/>';}
}
 $template=new template('../template/system','../cache/system');
    $template->display('/lybadd.html');
require ROOT_T.'/foot.tpl';
?>