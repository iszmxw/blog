<?php
$data = array (
  1 => 
  array (
    'id' => '1',
    'title' => '默认会员',
    'body' => '',
    'tablename' => 'detail',
    'mode' => '0',
    'num' => '0',
    'default_style' => 'default',
    'category_template' => 'category',
    'list_template' => 'list',
    'show_template' => 'show',
    'addtime' => '1382072744',
    'site' => '1',
  ),
);
?>