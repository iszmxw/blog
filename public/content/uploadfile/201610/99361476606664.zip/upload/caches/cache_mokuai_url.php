<?php
$data = array (
  'admin-0' => 
  array (
    'id' => '22',
    'module' => 'admin',
    'urlid' => '0',
    'urltitle' => '后台地址',
    'url' => '&amp;m=admin',
  ),
  'chongzhi-1' => 
  array (
    'id' => '11',
    'module' => 'chongzhi',
    'urlid' => '1',
    'urltitle' => '我的订单',
    'url' => '&amp;m=dingdan',
  ),
  'chongzhi-2' => 
  array (
    'id' => '12',
    'module' => 'chongzhi',
    'urlid' => '2',
    'urltitle' => '在线充值',
    'url' => '&amp;m=dingdan&amp;c=chongzhi',
  ),
  'chongzhi-3' => 
  array (
    'id' => '13',
    'module' => 'chongzhi',
    'urlid' => '3',
    'urltitle' => '账户记录',
    'url' => '&amp;m=dingdan&amp;c=jilu',
  ),
  'chongzhi-4' => 
  array (
    'id' => '14',
    'module' => 'chongzhi',
    'urlid' => '4',
    'urltitle' => '积分购买/兑换',
    'url' => '&amp;m=dingdan&amp;c=duihuan',
  ),
  'huiyuan-1' => 
  array (
    'id' => '1',
    'module' => 'huiyuan',
    'urlid' => '1',
    'urltitle' => '会员中心',
    'url' => '&amp;m=huiyuan',
  ),
  'huiyuan-2' => 
  array (
    'id' => '2',
    'module' => 'huiyuan',
    'urlid' => '2',
    'urltitle' => '会员登录',
    'url' => '&amp;m=huiyuan&amp;c=denglu',
  ),
  'huiyuan-3' => 
  array (
    'id' => '3',
    'module' => 'huiyuan',
    'urlid' => '3',
    'urltitle' => '会员注册',
    'url' => '&amp;m=huiyuan&amp;c=zhuce',
  ),
  'huiyuan-4' => 
  array (
    'id' => '4',
    'module' => 'huiyuan',
    'urlid' => '4',
    'urltitle' => '注册条款',
    'url' => '&amp;m=huiyuan&amp;c=tiaokuan',
  ),
  'huiyuan-5' => 
  array (
    'id' => '5',
    'module' => 'huiyuan',
    'urlid' => '5',
    'urltitle' => '找回密码',
    'url' => '&amp;m=huiyuan&amp;c=zhaohui',
  ),
  'huiyuan-6' => 
  array (
    'id' => '6',
    'module' => 'huiyuan',
    'urlid' => '6',
    'urltitle' => '修改邮箱/密码',
    'url' => '&amp;m=huiyuan&amp;c=zhanghao&amp;a=mima',
  ),
  'huiyuan-7' => 
  array (
    'id' => '7',
    'module' => 'huiyuan',
    'urlid' => '7',
    'urltitle' => '自助升级',
    'url' => '&amp;m=huiyuan&amp;c=zhanghao&amp;a=shengji',
  ),
  'huiyuan-8' => 
  array (
    'id' => '24',
    'module' => 'huiyuan',
    'urlid' => '8',
    'urltitle' => '会员动态',
    'url' => '&amp;m=huiyuan&amp;c=dongtai',
  ),
  'huiyuan-9' => 
  array (
    'id' => '23',
    'module' => 'huiyuan',
    'urlid' => '9',
    'urltitle' => '用户组',
    'url' => '&amp;m=huiyuan&amp;c=zu',
  ),
  'huiyuan-10' => 
  array (
    'id' => '8',
    'module' => 'huiyuan',
    'urlid' => '10',
    'urltitle' => '修改头像',
    'url' => '&amp;m=huiyuan&amp;c=zhanghao&amp;a=touxiang',
  ),
  'huiyuan-11' => 
  array (
    'id' => '9',
    'module' => 'huiyuan',
    'urlid' => '11',
    'urltitle' => '修改信息',
    'url' => '&amp;m=huiyuan&amp;c=zhanghao&amp;a=xinxi',
  ),
  'huiyuan-12' => 
  array (
    'id' => '10',
    'module' => 'huiyuan',
    'urlid' => '12',
    'urltitle' => '修改支付密码',
    'url' => '&amp;m=huiyuan&amp;c=zhanghao&amp;a=zhifumima',
  ),
  'index-0' => 
  array (
    'id' => '21',
    'module' => 'index',
    'urlid' => '0',
    'urltitle' => '网站首页',
    'url' => '&amp;m=index',
  ),
  'lianjie-1' => 
  array (
    'id' => '15',
    'module' => 'lianjie',
    'urlid' => '1',
    'urltitle' => '友情链接',
    'url' => '&amp;m=lianjie',
  ),
  'sousuo-1' => 
  array (
    'id' => '16',
    'module' => 'sousuo',
    'urlid' => '1',
    'urltitle' => '搜索首页',
    'url' => '&amp;m=sousuo',
  ),
  'xinxi-1' => 
  array (
    'id' => '17',
    'module' => 'xinxi',
    'urlid' => '1',
    'urltitle' => '发送短信息',
    'url' => '&amp;m=xinxi&amp;c=fasong',
  ),
  'xinxi-2' => 
  array (
    'id' => '18',
    'module' => 'xinxi',
    'urlid' => '2',
    'urltitle' => '收件箱',
    'url' => '&amp;m=xinxi&amp;c=shoujian',
  ),
  'xinxi-3' => 
  array (
    'id' => '19',
    'module' => 'xinxi',
    'urlid' => '3',
    'urltitle' => '发件箱',
    'url' => '&amp;m=xinxi&amp;c=fajian',
  ),
  'xinxi-4' => 
  array (
    'id' => '20',
    'module' => 'xinxi',
    'urlid' => '4',
    'urltitle' => '系统信息',
    'url' => '&amp;m=xinxi&amp;c=xitong',
  ),
);
?>