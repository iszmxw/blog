<?php
$data = array (
  'KF_index' => 
  array (
    'file' => 'index.php',
    'rewrite' => 'index.html',
    'url-1' => '0',
    'url-2' => '0',
    'url-3' => '0',
    'url-4' => '0',
    'url-5' => '0',
    'alias' => 'KF_index',
    'body' => '网站首页',
  ),
  'KF_paibanpage' => 
  array (
    'file' => 'index.php',
    'rewrite' => 'index/($id).html',
    'url-1' => '0',
    'url-2' => '0',
    'url-3' => '0',
    'url-4' => '0',
    'url-5' => '0',
    'alias' => 'KF_paibanpage',
    'body' => '新建页面',
  ),
  'KF_neironglist' => 
  array (
    'file' => 'index.php',
    'rewrite' => 'list-($catid)-($page|1).html',
    'url-1' => '0',
    'url-2' => '0',
    'url-3' => '0',
    'url-4' => '0',
    'url-5' => '0',
    'alias' => 'KF_neironglist',
    'body' => '内容列表',
  ),
  'KF_neirongshow' => 
  array (
    'file' => 'index.php',
    'rewrite' => 'show-($catid)-($id)-($p|1).html',
    'url-1' => '0',
    'url-2' => '0',
    'url-3' => '0',
    'url-4' => '0',
    'url-5' => '0',
    'alias' => 'KF_neirongshow',
    'body' => '内容详情',
  ),
  'KF_neirongreply' => 
  array (
    'file' => 'index.php',
    'rewrite' => 'reply-($catid)-($id)-($page|1).html',
    'url-1' => '0',
    'url-2' => '0',
    'url-3' => '0',
    'url-4' => '0',
    'url-5' => '0',
    'alias' => 'KF_neirongreply',
    'body' => '评论列表',
  ),
);
?>