<?php
$data = array (
  'mail_set_reg' => '0',
  'mail_set_editpwd' => '0',
  'mail_set_renzheng' => '0',
  'mail_set_zhaohui' => '0',
  'mail_set_order' => '0',
  'mail_set_payment' => '0',
);
?>