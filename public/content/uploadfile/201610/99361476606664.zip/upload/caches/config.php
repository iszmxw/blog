<?php

				define("CHARSET","utf-8");
			
			?>