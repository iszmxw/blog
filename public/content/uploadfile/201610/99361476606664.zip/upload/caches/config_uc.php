<?php
define('UC_CONNECT', 'mysql');
define('UC_USE', '0');
define('UC_API', '');
define('UC_IP', '');
define('UC_DBHOST', 'localhost');
define('UC_DBUSER', 'root');
define('UC_DBPW', '');
define('UC_DBNAME', 'discuz');
define('UC_DBTABLEPRE', '`discuz`.pre_ucenter_');
define('UC_DBCHARSET', 'utf8');
define('UC_APPID', '2');
define('UC_KEY', 'kuaifanpass');
define('UC_MSG', '0');
define('UC_DBCONNECT', '0');
define('UC_CHARSET', 'utf-8');
define('UC_PPP', '20');
?>