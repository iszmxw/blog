<?php
						if(!defined('IN_KUAIFAN'))die('Access Denied!');
						define('KUAIFAN_VERSION','5.0');
						define('KUAIFAN_RELEASE', '20160423');
					?>