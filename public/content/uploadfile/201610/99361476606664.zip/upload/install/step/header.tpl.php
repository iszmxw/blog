<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<title><?php echo $steps[$step];?> - KuaiFan CMS 5.x安装向导 </title>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<link rel="stylesheet" type="text/css" href="./css/common.css" />
	<script language="JavaScript" src="./images/jquery.min.js"></script>
</head>
<body>
<div id="header" style="overflow: hidden;">
	<h1 style="color: #FFFFFF; line-height: 26px; margin-left: 16px; margin-bottom: 8px;"><span class="green">KuaiFan CMS 5.x</span> 安装向导</h1>
</div>