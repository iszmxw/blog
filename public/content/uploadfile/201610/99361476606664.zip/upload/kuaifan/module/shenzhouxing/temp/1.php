<?php
$data = array (
  4 => 
  array (
    'id' => '4',
    'userid' => '1',
    'keyid' => '1',
    'orderid' => '2013120322701253428527',
    'cardno' => '7722001007210004795',
    'cardpwd' => '779291940977345223',
    'amt' => '50',
    'amts' => '42',
    'rate' => '16',
    'condition' => '失败-卡无效',
    'tongzhi' => '发送通知成功',
    'inputdate' => '1386068485',
    'endtime' => '1386068498',
    'backurl' => 'http://127.0.0.1:801/index.php?vs=1&sid=B0pqDyCcH4dJlS-QrkvvNOjf&m=shenzhouxing&c=fanhui&md5=zoYH2sI8&rs_code=2&rand=1390234019',
    'md5' => 'zoYH2sI8',
    'rs_code' => '2',
    'ip' => '127.0.0.1',
  ),
);
?>