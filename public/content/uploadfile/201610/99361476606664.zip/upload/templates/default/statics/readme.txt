css
#css样式存放目录

images
#图片存放目录

js
#js文件存放目录