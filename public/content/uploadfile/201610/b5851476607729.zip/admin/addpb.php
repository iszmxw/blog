<?php

 session_start(); if(isset($_SESSION['admin'])==false){header('location:login.php');exit;}

$title='增加自定义页面';
require 'head.tpl';
 
if(isset($_POST['add'])){

    if(!empty($_POST['pb_t']) and !empty($_POST['pb_nr'])){}else{die('增加页面内容为空,错误!');}

    if(preg_match('/.{2,15}/',$dbConn->escape(htmlspecialchars($_POST["pb_t"])))){ 
     $q=array(
'top'=>$dbConn->escape(htmlspecialchars($_POST['pb_t'])),
'foot'=>$dbConn->escape(htmlspecialchars($_POST['pb_nr']))); 

      $if=$dbConn->insert_array(DB_QZ.'_pb',$q);

      if($if){$echo='增加成功';}else{$echo='增加失败';} 

ailierror($echo);
   }
}

$template->display('/addpb.html');
 require 'foot.tpl';
?>