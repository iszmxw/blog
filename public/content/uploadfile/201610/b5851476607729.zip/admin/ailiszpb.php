<?php

 session_start(); if(isset($_SESSION['admin'])==false){header('location:login.php');exit;} 
$title='全局排版｜首页排版';
require 'head.tpl';

        if(isset($_POST['pb'])==TRUE){

        $q="UPDATE ".DB_QZ."_pb SET sypb='".$dbConn->escape(htmlspecialchars($_POST["pb_nr"]))."',top='".$dbConn->escape(htmlspecialchars($_POST["pb_t"]))."',foot='".$dbConn->escape(htmlspecialchars($_POST["pb_f"]))."' WHERE id='1' LIMIT 1";

     $insert=$dbConn->query($q);

if($insert){$echo='修改成功';}else{$echo='修改失败';}
ailierror($echo);
}
         $q="SELECT sypb,top,foot FROM ".DB_QZ."_pb WHERE id='1' LIMIT 1";
         $db=$dbConn->get_row($q);
$template->display('/ailiszpb.html');
require 'foot.tpl';
?>