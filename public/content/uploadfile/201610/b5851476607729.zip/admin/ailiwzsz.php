<?php
 session_start(); if(isset($_SESSION['admin'])==false){header('location:login.php');exit;}

$title='修改网站信息';
require 'head.tpl';

        if(isset($_POST['pb'])==TRUE){

$q="UPDATE ".DB_QZ."_www SET 
js='".$dbConn->escape(htmlspecialchars($_POST["gr"]))."',name='".$dbConn->escape(htmlspecialchars($_POST["user"]))."',qname='".$dbConn->escape(htmlspecialchars($_POST["pass"]))."',title='".$dbConn->escape(htmlspecialchars($_POST["title"]))."',gjz='".$dbConn->escape(htmlspecialchars($_POST["key"]))."',ms='".$dbConn->escape(htmlspecialchars($_POST["ms"]))."',host='".$dbConn->escape(htmlspecialchars($_POST["host"]))."' WHERE id='1' LIMIT 1";

     $insert=$dbConn->query($q);

if($insert){$echo='修改成功';}else{$echo='修改失败';}
ailierror($echo);
 }

     $q="SELECT * FROM ".DB_QZ."_www WHERE id='1' LIMIT 1";
     $db=$dbConn->get_row($q);
$template->display('/ailiwzsz.html');
require 'foot.tpl';
?>