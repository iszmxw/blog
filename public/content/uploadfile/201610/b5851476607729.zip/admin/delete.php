<?php
 session_start(); if(isset($_SESSION['admin'])==false){header('location:login.php');exit;}

$title='删除数据';
require 'head.tpl';

if(!isset($_GET['type']) and isset($_POST['id'])){exit();}

  if($_GET['type']=='blog'){

   for($i=0;$i<count($_POST['id']);$i++){
     $if=$dbConn->query("DELETE FROM ".DB_QZ."_article WHERE id='".(int)$_POST["id"][$i]."' LIMIT 1");
    if($if){$echo='删除成功';}else{$echo='删除失败';}
ailierror($echo);
   }
}

  if($_GET['type']=='link'){

   for($i=0;$i<count($_POST['id']);$i++){
     $if=$dbConn->query("DELETE FROM ".DB_QZ."_link WHERE id='".(int)$_POST["id"][$i]."' LIMIT 1");
    if($if){$echo='删除成功';}else{$echo='删除失败';}
ailierror($echo);
   }
}

 
  if($_GET['type']=='pb'){
     if($_POST["id"]=="1"){exit("系统故障");}

   for($i=0;$i<count($_POST['id']);$i++){
     $if=$dbConn->query("DELETE FROM ".DB_QZ."_pb WHERE id='".(int)$_POST["id"][$i]."' LIMIT 1");
    if($if){$echo='删除成功';}else{$echo='删除失败';}
ailierror($echo);
   }
}
 
  if($_GET['type']=='lyb'){

   for($i=0;$i<count($_POST['id']);$i++){
     $if=$dbConn->query("DELETE FROM ".DB_QZ."_lyb WHERE id='".(int)$_POST["id"][$i]."' LIMIT 1");
    if($if){$echo='删除成功';}else{$echo='删除失败';}
ailierror($echo);
   }
} 
 
require 'foot.tpl';
?>