<?php

$temple=array("/style.html",
"/system/articlelist.html",
"/system/articleread.html",
"/system/articletype.html",
"/system/linkadd.html",
"/system/linktype.html",
"/system/lyblist.html",
"/system/lybadd.html",
"/system/lybread.html",

"/admin/addblog.html",
"/admin/addpb.html",
"/admin/ailimm.html",
"/admin/ailiszpb.html",
"/admin/ailiwzsz.html",
"/admin/bloglist.html",
"/admin/foot.html",
"/admin/head.html",
"/admin/index.html",
"/admin/linklist.html",
"/admin/login.html",
"/admin/lyblist.html",
"/admin/pblist.html",
"/admin/style.html",
"/admin/updateblog.html",
"/admin/updatelink.html",
"/admin/updatepb.html");

$head=array("样式切换页",
"文章列表页",
"文章阅读页",
"文章分类页",
"友链增加页",
"友链分类页",
"留言列表页",
"留言增加页",
"留言阅读页",

"增加文章页",
"增加页面页",
"修改信息页",
"全局设置页",
"网站设置页",
"文章列表页",
"后台底部页",
"后台顶部页",
"后台开始页",
"友链列表页",
"后台登录页",
"留言管理页",
"页面管理页",
"风格管理页",
"修改文章页",
"修改友链页",
"修改排班页");

session_start(); if(isset($_SESSION['admin'])==false){header('location:login.php');exit;}

$title="模板管理";
require './head.tpl';

if(isset($_GET['path'])==TRUE){

    if(isset($_POST['submit'])==TRUE){

if(file_put_contents('../template'.$_GET['path'],$_POST['text'])){echo '成功修改模板<br/>';}else{echo '写入失败，可能该空间不支持写入文件<br/>';}
     }
    $file=htmlspecialchars(file_get_contents('../template'.$_GET['path']));

echo '【编辑模板】<br/>
<form action="entertemple.php?path='.$_GET['path'].'" method="post">
<textarea name="text" rows="30%">'.$file.'</textarea><br/>
<input type="submit" name="submit" value="保存模板内容"/>
</form>';
}else{

echo '【模板管理】<br/>';
  for($i=0;$i<26;$i++){
    echo '['.$head[$i].']<a href="entertemple.php?path='.$temple[$i].'">编辑</a>';
    if(($i%2)==0){echo '<br/>';}
  }
}
require './foot.tpl';
?>