<?php
if(isset($_SESSION["admin"])){$_SESSION["adminstatus"]=TRUE;}
define("U","admin");
define("P","98986546");
?>