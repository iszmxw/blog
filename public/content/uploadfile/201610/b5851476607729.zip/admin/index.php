<?php

session_start(); if(isset($_SESSION['admin'])==false){header('location:login.php');exit;}

$title="艾黎管理系统";
require './head.tpl';

       $q="SELECT name FROM ".DB_QZ."_admin WHERE id='".$_SESSION["admin"]."'";
       $v=$dbConn->count("SELECT * FROM ".DB_QZ."_msg WHERE 
zt='wd'");
       $s=$dbConn->count("SELECT * FROM ".DB_QZ."_lyb WHERE zt='未'");
       $y=$dbConn->count("SELECT * FROM ".DB_QZ."_link WHERE sh='fsh'");

     $r=$dbConn->get_row("SELECT zf,zfw,ip,zip,time FROM ".DB_QZ."_count WHERE id='1' LIMIT 1");

       $fetch=$dbConn->get_row($q);
       if(@file_get_contents('version.php')!=@file_get_contents('http://ailiw.cn/version.txt')){echo '<font color="red">提示:该程序已经更新，可使用在线升级更新程序！</font><br/>';}else{}

$template->display('/index.html');

require 'foot.tpl';
?>