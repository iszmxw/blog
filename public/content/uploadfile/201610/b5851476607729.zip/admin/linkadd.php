<?php
 session_start(); if(isset($_SESSION['admin'])==false){header('location:login.php');exit;}

$title='增加友链';
require 'head.tpl';

  if(isset($_POST['submit'])==TRUE){

     $name=$dbConn->escape(
htmlspecialchars($_POST['name']));
     $qname=$dbConn->escape(
htmlspecialchars($_POST['qname'])); 
     $nam=preg_match('/^[a-zA-Z0-9\x{4e00}-\x{9fa5}]{2}$/u',$name);
     $qnam=preg_match('/^[a-zA-Z0-9\x{4e00}-\x{9fa5}]{4,8}$/u',$qname);
    $url=preg_match('/^(http:\/\/)([a-z0-9A-Z]{1,62}\.)*[a-zA-Z]{2,62}/Uis',$_POST['url']);

 if($nam && $qnam && $url ){
   
$sql="SELECT * FROM ".DB_QZ."_link WHERE `name`='".$name."' and `url`='".$_POST["url"]."' LIMIT 1";
    if($dbConn->count($sql)==1){exit('该数据已存在');}
     $q=array('name'=>$name,'lock'=>'0','logo'=>'0','qname'=>$qname,'sortid'=>(int)$_POST['fl'],'url'=>$_POST['url'],'js'=>'这个站不错!','link'=>'0','xd'=>'0','sh'=>'1','ko'=>'0','kt'=>'0','iko'=>'0','ikt'=>'0','time'=>time()); 

        $if=$dbConn->insert_array(DB_QZ.'_link',$q);

        $count=$dbConn->get_row('SELECT id FROM '.DB_QZ.'_link ORDER BY id DESC LIMIT 1');

          if($if){
$v=$dbConn->get_row("SELECT * FROM ".DB_QZ."_www WHERE id='1' LIMIT 1");

     echo '增加成功！<br/>回链:<input type="text" size="23" id="input" value="http://'.$_SERVER['HTTP_HOST'].'/comeurl.php?id='.$count['id'].'"/><HR/>';}else{echo '申请失败';}
  }else{echo '填写不合法';} 
}

  $m= "SELECT * FROM ".DB_QZ."_sort WHERE `lock`='link' ORDER BY `id` ASC";
  $for=$dbConn->select($m);
  $count='SELECT id FROM '.DB_QZ.'_link ORDER BY id DESC LIMIT 1';
   if($dbConn->count($count)>0){
    $count=$dbConn->get_row($count);
    $count=$count['id'];
     }
    $count=(int)$count+1;
    $url='http://'.$_SERVER['HTTP_HOST'].'/comeurl.php?id='.$count;
   
echo ' <form action="linkadd.php" method="post">
预计回链:<br/>
<span style="color:red">'.$url.'</span><br/>
*网站简称:<br/>
<input type="text" name="name"  placeholder="2个字符,支持数字、字母、汉字"/><br/>

*网站全称:<br/>
<input type="text" name="qname"  placeholder="4字符,支持数字,字母,汉字" /><br/>

*网站链接:<br/>
<input type="text" name="url" placeholder="以http://开头，必选" /><br/>
*分类:<select name="fl" class="select">';

foreach($for as $fora){
echo '<option value="'.$fora['id'].'">'.$fora['name'].'</option>';
}
echo '</select><br/>
<input type="submit" value="提交" name="submit"></form>';
require './foot.tpl';
?>