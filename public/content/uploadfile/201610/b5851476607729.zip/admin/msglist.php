<?php

session_start();
if(isset($_SESSION['admin'])){

$title='收信箱';
include 'head.tpl';

echo '<div class="subtitle">★收信箱<a href="msglist.php?a=yd">已读</a>|<a href="msglist.php">未读</a>★</div>';

       if(isset($_GET['a'])){

         if(isset($_GET['p'])){$p=(int)$_GET['p'];}else{$p=1;} 

    $page=($p-1)*10;
    $q=$dbConn->count("SELECT * FROM ".DB_QZ."_msg WHERE zt='yd'");

       $m= "SELECT * FROM ".DB_QZ."_msg WHERE zt='yd' ORDER BY id DESC LIMIT {$page},10";

        if($dbConn->count($m)>0){ 
     foreach($dbConn->select($m) as $array){
 
      echo ' <a href="msglist.php?xl=no&mid='.$array['id'].'">标记为未读</a> [已读]'.$array['name'].':<br/>'.iconv_substr($array['text'],0,500,'utf8').'<br/>»发信人:'.$array['name'].'/'.date('Y_m_d_i_s',$array['time']).'<hr/>';
 
          }

       }else{echo('暂无最新已读消息');}
 
    }elseif(isset($_GET['xl']) and isset($_GET['mid'])){

 
         $w= "SELECT * FROM ".DB_QZ."_msg WHERE id='".(int)$_GET["mid"]."' LIMIT 1";

    if($dbConn->count($w)>0){ 
      if($_GET['xl']=='on'){

       $t="UPDATE ".DB_QZ."_msg SET zt='yd' WHERE id='".(int)$_GET["mid"]."' LIMIT 1";

      }elseif($_GET['xl']=='no'){

      $t="UPDATE ".DB_QZ."_msg SET zt='wd' WHERE id='".(int)$_GET["mid"]."' LIMIT 1"; 
     }

      $dbConn->query($t);
    }
    }else{

       if(isset($_GET['p'])){$p=$_GET['p'];}else{$p=1;} 

    $page=($p-1)*10;
    $q=$dbConn->count("SELECT * FROM ".DB_QZ."_msg WHERE zt='yd'");

 

         $m= "SELECT * FROM ".DB_QZ."_msg WHERE zt='wd' ORDER BY id DESC";

        if($dbConn->count($m)>0){ 
     foreach($dbConn->select($m) as $array){

      echo ' »<a href="msglist.php?xl=on&mid='.$array['id'].'">标记为已读</a> [未读]'.$array['name'].':<br/>'.iconv_substr($array['text'],0,500,'utf8').'<br/>♀发信人:'.$array['name'].'/'.date('Y_m_d_i_s',$array['time']).'♀<hr/>';

          }
   }else{echo '暂无未读消息';}
       }

include 'foot.tpl';
}else{}
?>