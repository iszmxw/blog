<?php
/*
* wap phpmyadmin
* ionutvmi
* pimp-wap.net
*/
error_reporting(0);
include "lang/index.php";
include '../../config.php';
include 'head.php';
$e=base64_encode(DB_HOST."^^^".DB_USER."^^^".DB_PASS."^^^".DB_NAME);
print"<div class='shout'> ".$lang["WELCOME"]." $dbu <br/>
<br/> &#187; <a href='tables.php?k=$e'>".$lang["ENTER"]."</a> &#171;
</div>";

include 'foot.php';
?>