<?php
 session_start(); if(isset($_SESSION['admin'])==false){header('location:login.php');exit;}

$title='修改数据';
require 'head.tpl'; 

if(!isset($_GET['type']) or !isset($_GET['id'])){exit;}
$id=(int)$_GET['id'];

if($_GET['type']=='blog'){
   if(isset($_POST['submit'])){
   $q=$dbConn->query("UPDATE ".DB_QZ."_article SET title='".$dbConn->escape(
htmlspecialchars($_POST["title"]))."',sortid='".$dbConn->escape(
htmlspecialchars($_POST["fl"]))."',text='".$dbConn->escape(
htmlspecialchars($_POST["text"]))."'  WHERE id='".$id."' limit 1");

    if($q){$echo='修改成功';
    }else{$echo='修改失败！';}
ailierror($echo);
   }

    $t=$dbConn->get_row("SELECT * FROM ".DB_QZ."_article WHERE id='".$id."' LIMIT 1");
    $v=$dbConn->select("SELECT * FROM ".DB_QZ."_sort WHERE `lock`='article'");

    $template->display('/updateblog.html');
}

if($_GET['type']=='link'){

 if(isset($_POST['submit'])){
   $if=$dbConn->query("UPDATE `".DB_QZ."_link` SET `name`='".$dbConn->escape(
htmlspecialchars($_POST["name"]))."',
`qname`='".$dbConn->escape(
htmlspecialchars($_POST["qname"]))."',
`sortid`='".addslashes(
htmlspecialchars($_POST["fl"]))."',
`url`='".$dbConn->escape(
htmlspecialchars($_POST["url"]))."',
`logo`='".$dbConn->escape(
htmlspecialchars($_POST["logo"]))."',
`link`='".$dbConn->escape(
htmlspecialchars($_POST["link"]))."',
`js`='".$dbConn->escape(
htmlspecialchars($_POST["js"]))."',
`sh`='".$_POST["ai"]."',
`xd`='".$_POST["xd"]."' WHERE `id`='".$id."' LIMIT 1");


    if($if){$echo='更新数据成功';}else{$echo='更新数据失败';}

ailierror($echo);}
      $t=$dbConn->get_row("SELECT * FROM ".DB_QZ."_link WHERE id='".$id."' LIMIT 1");
      $v=$dbConn->select("SELECT * FROM `".DB_QZ."_sort` WHERE `lock`='link'");

$template->display('/updatelink.html');
 }

if($_GET["type"]=="pb"){

    if(isset($_POST['submit'])==TRUE){

       $q="UPDATE ".DB_QZ."_pb SET top='".$dbConn->escape(htmlspecialchars($_POST["pb_t"]))."',foot='".$dbConn->escape(htmlspecialchars($_POST["pb_nr"]))."' WHERE id=".$id;

     $insert=$dbConn->query($q);

if($insert){$echo='修改成功';}else{$echo='修改失败';}
ailierror($echo);

   }
  if($id==1 or $id<1){exit('id值错误');}

     $get="SELECT top,foot FROM ".DB_QZ."_pb WHERE id='".$id."' LIMIT 1";
      if($dbConn->count($get)!=1){exit('不存在该页面');}
     $for=$dbConn->get_row($get);
 
$template->display('/updatepb.html');

} 
require 'foot.tpl';
?>