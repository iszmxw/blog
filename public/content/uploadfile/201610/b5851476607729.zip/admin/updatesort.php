<?php
 session_start(); if(isset($_SESSION['admin'])==false){header('location:login.php');exit;}

$title='增加分类';
require 'head.tpl';
 if(isset($_POST['submt'])){

if(preg_match('/^[a-zA-Z0-9\x{4e00}-\x{9fa5}]{2,4}$/u',$dbConn->escape(htmlspecialchars($_POST["sortname"])))){ 
        $q="UPDATE ".DB_QZ."_sort SET `name`='".$dbConn->escape(htmlspecialchars($_POST["sortname"]))."' WHERE `id`='".(int)$_POST["id"]."' LIMIT 1";

        $if=$dbConn->query($q);

          if($if){$echo='修改成功';}else{$echo='修改失败';}
ailierror($echo);
   }else{echo '非法填写';}
}
 
$select=$dbConn->select("SELECT id,name FROM ".DB_QZ."_sort ORDER BY `id` ASC");

echo '<form action="updatesort.php" method="post">
<select name="id">';

foreach($select as $array){
echo '<option value="'.$array['id'].'">'.$array['id'].'_'.$array['name'].'</option>';
}

echo '</select>»修改为:<input type="text" size="10" name="sortname" />
<input type="submit" value="修改" name="submt"/></form>
<a href="./">»返回管理首页</a>';
require 'foot.tpl';
?>