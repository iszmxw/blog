<?php
function wzubb($string){
   $string=preg_replace_callback('/\[html\](.*)\[\/html]/',"html",$string);
return $string;
}
?>