<?php
session_start();
 if(isset($_GET['kid'])==false){exit;}
header('Content-type:text/html;charset=utf-8');
date_default_timezone_set('PRC');
require './config.php';
require ROOT_T.'/require.php';
 
    $kid=(int)$_GET['kid'];
 
    $sql="SELECT url,sh FROM ".DB_QZ."_link WHERE id='".$kid."' LIMIT 1";
    if($dbConn->count($sql)!=1){
      header('location:./');exit;
    }else{
          $ip="SELECT * FROM ".DB_QZ."_ip WHERE `sip`='".$_SERVER['REMOTE_ADDR']."' and `lid`='{$kid}' and `text`='链出'";
         if($dbConn->count($ip)>0){
          }else{

     $q=array(
'sip'=>$_SERVER['REMOTE_ADDR'],
'lid'=>$kid,
'text'=>'链出',
'time'=>time());
     $dbConn->insert_array(DB_QZ.'_ip',$q);
 
$dbConn->query("UPDATE ".DB_QZ."_link SET ikt=ikt+1 WHERE id='{$kid}' LIMIT 1");
  }
   if(!isset($_SESSION[$kid])){

     $dbConn->query("UPDATE ".DB_QZ."_link SET `kt`=kt+1 WHERE id='{$kid}' LIMIT 1");
   $_SESSION[$kid]='ailiw.cn';
  } 
 
      $geturl=$dbConn->get_row($sql);

if($geturl['sh']==0){exit('未审核');}
    header('location:'.$geturl['url']);}
?>