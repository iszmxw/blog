<?php
require ROOT_T.'/inc/pbubb.php';
require ROOT_T.'/inc/mysql.class.php';
require ROOT_T.'/inc/class.php';
require ROOT_T.'/inc/runtime.php';
require ROOT_T.'/inc/template.php';
$pbubb=new ubb();
$runtime=new runtime();
      $runtime->start();
$dbConn=new dbConn(DB_HOST,DB_USER,DB_PASS,DB_NAME);
?>