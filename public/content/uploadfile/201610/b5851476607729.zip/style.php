<?php
$title='选择风格';
require './config.php';
require ROOT_T.'/require.php';
require ROOT_T.'/head.tpl';

 $template=new template('./template','./cache');
 
        if(isset($_GET['id'])==TRUE){

$qhcss=$dbConn->get_row("SELECT text FROM ".DB_QZ."_style WHERE id='".(int)$_GET["id"]."' LIMIT 1");
 
unset($_SESSION['css']);
 $_SESSION['css']=$qhcss["text"]; 
 ailierror('切换风格成功！'); 
}
    $q="SELECT * FROM ".DB_QZ."_style";
    $page["page"]=isset($_GET['page'])?
$_GET['page']:1;
    $page["size"]=($page["page"]-1)*10;
    $m= "SELECT * FROM ".DB_QZ."_style ORDER BY id DESC LIMIT {$page["size"]},10";
    $for=$dbConn->select($m); 
    $page["count"]=$dbConn->count($q);
    $page["num"]=ceil($page["count"]/10);
     $page["pageNext"]=$page["page"]+1;
     $page["pageFront"]=$page["page"]-1;
    if($page["page"]<$page["num"] and $page["page"]<2){
      $page["pre"]=true;
$page["next"]=false;$page["front"]=false;
     }elseif($page["page"]>1 and $page["page"]<$page["num"]){
      $page["next"]=true;
$page["pre"]=false;$page["front"]=false;
     }elseif($page["page"]==$page["num"] and $page["page"]>1){
         $page["next"]=false;
$page["pre"]=false;$page["front"]=true;
     }else{
        $page["next"]=false;
$page["pre"]=false;$page["front"]=false;
     }
    $template->display('/style.html');
require ROOT_T.'/foot.tpl';
?>