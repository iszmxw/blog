<?php
if(isset($_GET['aid'])==false){
exit;}
  $id=(int)$_GET['aid'];
require '../config.php';
require ROOT_T.'/require.php';
  $subtitle="SELECT title FROM ".DB_QZ."_article WHERE id='".$id."' LIMIT 1";
  if($dbConn->count($subtitle)==1){
    $title=$dbConn->get_row($subtitle);
    $title=$title["title"];
require ROOT_T.'/head.tpl';

    $m="SELECT * FROM ".DB_QZ."_article WHERE id='".$id."' LIMIT 1";
    $f="SELECT * FROM ".DB_QZ."_admin WHERE id='1' LIMIT 1";
    $s="SELECT * FROM ".DB_QZ."_value WHERE aid='".$id."' ORDER BY id DESC";

    if(!isset($_SESSION['read'])){
      $q=$dbConn->query("UPDATE ".DB_QZ."_article SET cs=cs+1 WHERE id='".$id."' LIMIT 1");
$_SESSION['read']='ailiw.cn';}

     $x="SELECT * FROM ".DB_QZ."_article ORDER BY rand() LIMIT 2";
 
     $article=$dbConn->get_row($m);
     $articletime=date('Y/m/d',$article['time']);
require ROOT_T.'/inc/article.class.php';
     $articletext= htmlspecialchars_decode(stripslashes(wzubb($article["text"])));
     $admin=$dbConn->get_row($f);
    $countv=$dbConn->count($s);
    if($countv>0){
      $selectv=$dbConn->select($s);}else{$selectv=NULL;}
 $template=new template('../template/system','../cache/system');
    $template->display('/articleread.html');
require ROOT_T.'/foot.tpl';
}
?>