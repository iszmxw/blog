<?php
session_start();
date_default_timezone_set('PRC');
header('Content-type:text/html;charset=utf-8');

     if(isset($_POST['aip']) and isset($_POST['submit']) and  !empty($_POST['name']) and !empty($_POST['text'])){

//    if($_SERVER['HTTP_HOST']!='wap.t2dt.com'){die();}
    if(isset($_SESSION["v"])){

    if($_SESSION["v"]>time()){

    die("请不要快速回复");}
     }else{
     include '../config.php'; 
     include '../inc/mysql.class.php';

      define('ROOT_PATH','../');
      

     $dbConn=new dbConn(DB_HOST,DB_USER,DB_PASS,DB_NAME); 

       $m="SELECT * FROM ".DB_QZ."_article WHERE id='".(int)$_POST["aip"]."' LIMIT 1";


   if(isset($_POST['inform'])){
      if($_POST['inform']=='1'){

       $msg=array(
'name'=>$dbConn->escape(htmlspecialchars($_POST['name'])),
'text'=>'<a href="../article/read.php?aid='.$_POST['aip'].'">点击查看来源</a>，'.$dbConn->escape(htmlspecialchars($_POST['text'])),
'zt'=>'wd',
'time'=>time());
          $dbConn->insert_array($db['qz'].'_msg',$msg);

      }

    }

        if($dbConn->count($m)>0){ 
 
      $q=array(
'aid'=>(int)$_POST['aip'],
'name'=>$dbConn->escape(htmlspecialchars($_POST['name'])),
'text'=>$dbConn->escape(htmlspecialchars($_POST['text'])),
'time'=>time());

    $dbConn->insert_array(DB_QZ.'_value',$q);

    }else{echo '文章不存在';}

header('refresh:2;url=articleread.php?aid='.(int)$_POST['aip']);

       echo '回复成功!<br/><font color="red">*2秒后自动跳转到文章</font>';

   $_SESSION["v"]=time()+120;
  }
}else{echo '请认真填写';}

?>
