<?php
require '../config.php';
require ROOT_T.'/require.php';
 
if(isset($_GET['id'])==false){exit;}
  $id=(int)$_GET['id'];
  $q="SELECT title,text,name,time FROM ".DB_QZ."_lyb WHERE id='{$id}' LIMIT 1";

   $get=$dbConn->get_row($q);
   $title=$get['title'];
require ROOT_T.'/head.tpl';
 if($dbConn->count($q)==1){
     if(isset($_SESSION['admin'])){
     $dbConn->query("UPDATE `".DB_QZ."_lyb` SET `zt`='已' WHERE `id`='{$id}' LIMIT 1");
      }
 
   $gettime=date('Y/m/d H:i',$get['time']);
 $template=new template('../template/system','../cache/system'); 

    $template->display('/lybread.html');
require ROOT_T.'/foot.tpl';
}
?>