<?php
/*
Plugin Name: UA判断跳转代码
Version: 1.0
Plugin URL: http://hbblog.cn
Description: 轻巧的UA判断插件，自动判断UA，目前是手机UA访问跳转到手机站，可以分别对安卓，苹果，黑莓，WP设置跳转【二次开发请联系我QQ908570107】
Author: 追乐
Author Email: 908570107@qq.com
Author URL: http://www.hbblog.cn
*/
!defined('EMLOG_ROOT') && exit('access deined!');

function judge_mobile(){
echo '
<script src="'.BLOG_URL.'content/plugins/judge_mobile/mobile.js"></script>
'."\r\n";
}
addAction('index_head', 'judge_mobile');